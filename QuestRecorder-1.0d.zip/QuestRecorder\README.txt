Quest Recorder - BuddyCron plugin by LethToxic
==============================================

You play it once, it makes the profile. That's the idea.

Do a quest area by hand with the recorder on, and you get a profile that does it the same way you did.
Same stuff clicked, same order, same spots, same fights. The recorder only watches, it never touches
your character.


INSTALL
-------
Put the QuestRecorder folder in BuddyCron\Plugins and restart BuddyCron. Tick Quest Recorder in the
plugin list. Done.

If it doesn't show up, check the log for "Compiler Error" and send it to me.


RECORDING
---------
Stop the bot, tick Quest Recorder and it starts recording on its own. Then just play.

Ctrl+Shift+Z  - undo a misclick (do it straight away)
Ctrl+Shift+M  - drop a marker where you're standing (good for doors, corners, phase edges)

Hit "Stop recording" when you're done. If the bot runs for a bit (or you use Combat Assist) it just pauses,
it only records what you do yourself. Loading screens are fine.


YOUR PROFILE
------------
It gets saved while you play, in Profiles\Recorded\<planet>. Load that one in BuddyCron.

Some things it does for you:
- uses every object at the spot you used it, in your order, and never re-uses one that already counted
- fights where you fought and stops at the counts you got to
- talks, pick-ups, hand-ins, holocoms and rewards where you did them
- elevators to the floor you picked
- Heroic Transport shuttles, used the same way you did
- follows your footsteps between steps
- after a restart it carries on from where it was

Want your name on it? Set "Your name for credits" in the settings and every profile you make says
"Recorded by <you>".


TASK TRACKER
------------
The window shows each quest task as it ticks and what the profile will do for it. If you see "!!" the
recorder missed what you did there - just redo that bit while you're still there. With BuddyCron's
overlay on you get a heads-up in game as well.


OLD RECORDINGS
--------------
"Make profile from a recording" rebuilds a profile from any old recording (.csv) with the newest version
of the plugin. No need to play it again.


CONTROL PANEL
-------------
Fix or build a profile without touching the XML. Click "Control panel" and open a profile.

Pick a step in the list and remove it or move it. To add one, pick what the bot should do from the list
(quests, clicking, fighting, mission items, walking, planets, waiting, stopping and so on).
No need to add taxis, elevators, quick travel, vendor runs or looting - BuddyCron does those on its own.
It reads your target and quests from the game, and tells you what the bot will do before you add it.

Everything saves straight away and keeps a backup, so "Undo last fix" always gets you back.
Reload the profile in BuddyCron after changing it.


FILES
-----
"Open recordings folder" shows the raw recordings: a .txt you can read and a .csv the plugin uses.
The .txt has your character name in it, the profiles don't.


UPDATES
-------
When there's a new version you get a pop-up when BuddyCron starts. Click Yes, restart BuddyCron, done.
Your old version is kept in PluginBackups and "Undo update" puts it back.


TIPS
----
- It copies your mistakes too, so walk the route you actually want.
- If someone else just used "your" object, the bot waits for it to come back.
- Run a new profile once and watch it before you share it.
- Problems? Look for [Quest Recorder] lines in the BuddyCron log and send them over.
