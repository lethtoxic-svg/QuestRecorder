// Quest Recorder - made by LethToxic.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace QuestRecorder
{
    /// <summary>The ready-to-load profile: a REPLAY of the recording.</summary>
    internal static class ReplayBuilder
    {
        private sealed class Use
        {
            public string Name;
            public Vec3 Pos;
            public double At;
            public bool Cast;
            public Vec3 Stand;
        }

        private sealed class Kill
        {
            public string Name;
            public Vec3 Pos;
            public double At;
        }

        /// <summary>Stands in for "Heroic Transport: &lt;mission&gt;" until the mission is known.</summary>
        private const string HeroicMark = "Heroic Transport: @mission@";

        private sealed class Step
        {
            public string Kind = string.Empty;
            public string Gate;
            public string Comment = string.Empty;
            public readonly List<string> Lines = new List<string>();
            public ulong Quest;
            public int Task = -1;
            public List<Kill> Kills;
        }

        private static readonly HashSet<string> Stop = new HashSet<string>(StringComparer.Ordinal)
        {
            "container", "containers", "return", "defeat", "destroy", "recover", "speak", "mission", "with", "from",
            "acquire", "take", "find", "into", "your",
        };

        private static string X(Vec3 v)
        {
            return string.Format(CultureInfo.InvariantCulture, "{0:0.###},{1:0.###},{2:0.###}", v.X, v.Y, v.Z);
        }

        /// <summary>The "Undo last action" hotkey writes a marker with this note.</summary>
        public const string UndoNote = "Undo last action";

        /// <summary>The player's own name for the "Recorded by" credit (setting "Your name for credits"); empty = none.</summary>
        /// <summary>Metres between walk points along your route (the navigator does the rest).</summary>
        public static float WalkSpacing = 0f; // 0 = no footsteps: BuddyCron walks between the steps by itself

        public static string CreditName = string.Empty;

        private const string RideKey = "\u0001ride|";

        /// <summary>The game's own travel abilities (BuddyCron's navigator does travel itself, so these are not mission items).</summary>
        private static bool IsTravelAbility(string name)
        {
            foreach (string s in new[] { "Quick Travel", "Fleet Pass", "Priority Transport", "Stronghold", "Return to", "Recall", "Travel to" })
                if (name.IndexOf(s, StringComparison.OrdinalIgnoreCase) >= 0)
                    return true;
            return false;
        }

        /// <summary>"You are still on the side you rode from": the height when the lift changes floors by 2 m or more,
        /// else the axis you moved most along, split halfway between where you stood and where you came out.</summary>
        private static string SideOf(Vec3 from, Vec3 to)
        {
            float dx = to.X - from.X, dy = to.Y - from.Y, dz = to.Z - from.Z;
            string axis;
            float a, b;
            if ((Math.Abs(dy) >= 2f && Math.Sqrt(dx * dx + dz * dz) < 10.0) || (Math.Abs(dy) >= Math.Abs(dx) && Math.Abs(dy) >= Math.Abs(dz)))
            {
                axis = "Y"; a = from.Y; b = to.Y;
            }
            else if (Math.Abs(dx) >= Math.Abs(dz))
            {
                axis = "X"; a = from.X; b = to.X;
            }
            else
            {
                axis = "Z"; a = from.Z; b = to.Z;
            }
            float mid = (a + b) / 2f;
            return string.Format(CultureInfo.InvariantCulture, "(Me.Position.{0} {1} {2:0.##})", axis, a > b ? "&gt;" : "&lt;", mid);
        }

        private static string A(string s)
        {
            return Fmt.XmlAttr(s ?? string.Empty);
        }

        private static List<string> Words(string s)
        {
            var list = new List<string>();
            foreach (string w in (s ?? string.Empty).ToLowerInvariant().Split(new[] { ' ', ',', '.', ':', '(', ')', '\'', '"', '/' }, StringSplitOptions.RemoveEmptyEntries))
            {
                if (w.Length >= 4 && !Stop.Contains(w))
                    list.Add(w);
            }
            return list;
        }

        private static bool Shares(string objectName, List<string> objective)
        {
            foreach (string w in Words(objectName))
                if (objective.Contains(w))
                    return true;
            return false;
        }

        public static string Build(IList<RecEvent> events, string profileName, string fileName, string recordingName)
        {
            return Build(events, profileName, fileName, recordingName, null);
        }

        /// <summary>Task tracker: one line per quest task / step the recording caught, with what the profile will do for it.</summary>
        public static List<string> Trace(IList<RecEvent> events)
        {
            var trace = new List<string>();
            Build(events, "trace", string.Empty, string.Empty, trace);
            return trace;
        }

        private static string Attr(string line, string name)
        {
            int i = line.IndexOf(" " + name + "=\"", StringComparison.Ordinal);
            if (i < 0)
                return string.Empty;
            i += name.Length + 3;
            int j = line.IndexOf('"', i);
            return j > i ? line.Substring(i, j - i) : string.Empty;
        }

        private static void FillTrace(List<Step> steps, List<string> trace)
        {
            int n = 0;
            foreach (Step s in steps)
            {
                string what;
                switch (s.Kind)
                {
                    case "Pickup":
                        what = "pick up";
                        break;
                    case "Complete":
                        what = "hand in";
                        break;
                    case "Ride":
                        what = s.Lines.Count > 0 && s.Lines[0].StartsWith("<UseItem", StringComparison.Ordinal) ? "use " + Attr(s.Lines[0], "ItemName") + " (it takes you there)" : s.Lines.Count > 0 && s.Lines[0].StartsWith("<UseTransport", StringComparison.Ordinal)
                            ? "take the lift to " + Attr(s.Lines[0], "Option")
                            : "walk out of the lift (BuddyCron takes it)";
                        break;
                    case "Grind":
                    {
                        var mobs = new List<string>();
                        if (s.Kills != null)
                            foreach (Kill k in s.Kills)
                                if (!mobs.Contains(k.Name))
                                    mobs.Add(k.Name);
                        what = "fight " + string.Join(", ", mobs);
                        foreach (string l in s.Lines)
                            if (l.StartsWith("<UseObject", StringComparison.Ordinal))
                                what = "use " + Attr(l, "ObjectName") + " at " + Attr(l, "XYZ") + ", then " + what;
                            else if (l.StartsWith("<Interact", StringComparison.Ordinal))
                                what = "click " + Attr(l, "Name") + " (it starts the fight), then " + what;
                        break;
                    }
                    case "Use":
                    {
                        var objs = new List<string>();
                        foreach (string l in s.Lines)
                            if (l.StartsWith("<UseObject", StringComparison.Ordinal))
                                objs.Add("use " + Attr(l, "ObjectName") + " at " + Attr(l, "XYZ"));
                            else if (l.StartsWith("<Interact", StringComparison.Ordinal))
                                objs.Add("click " + Attr(l, "Name"));
                        what = string.Join(" -> ", objs);
                        break;
                    }
                    case "Talk":
                        what = "talk to " + Attr(s.Lines.Count > 0 ? s.Lines[s.Lines.Count - 1] : string.Empty, "Name");
                        break;
                    case "Item":
                        what = "use item " + Attr(s.Lines.Count > 0 ? s.Lines[s.Lines.Count - 1] : string.Empty, "ItemName");
                        break;
                    case "Holocom":
                        what = "answer the holocom";
                        break;
                    case "Walk":
                        // a counted task needs an action; a step that ticked on arrival is a "go to" step
                        what = s.Comment.IndexOf(": step ", StringComparison.Ordinal) < 0
                            ?"!! nothing caught for this count - the bot would only walk to where it ticked"
                            : "walk there (it ticked when you arrived)";
                        break;
                    default:
                        continue; // walks between steps, skipped steps
                }
                n++;
                trace.Add(n.ToString(CultureInfo.InvariantCulture) + ". " + s.Comment + "  ->  " + what);
            }
        }

        private static string Build(IList<RecEvent> events, string profileName, string fileName, string recordingName, List<string> trace)
        {
            // lifts and taxis are ridden by the navigator: clicks on them are not object uses
            var transport = new HashSet<string>(StringComparer.Ordinal);
            foreach (RecEvent e in events)
            {
                if ((e.Kind == EvKind.ElevatorOpen || e.Kind == EvKind.ElevatorRide || e.Kind == EvKind.TaxiOpen || e.Kind == EvKind.TaxiStart || e.Kind == EvKind.TaxiEnd) &&
                    e.Target != null && e.Target.Name.Length > 0)
                    transport.Add(e.Target.Name);
            }

            // every named object you used anywhere in the recording (for a cast the game did not tie to an object)
            var allUses = new List<Use>();
            foreach (RecEvent e in events)
            {
                if ((e.Kind == EvKind.ObjectClick || e.Kind == EvKind.Cast) && e.Target != null && e.Target.Kind == ObjKind.Placeable &&
                    e.Target.Name.Length > 0 && !e.Target.Name.StartsWith("#", StringComparison.Ordinal) && !transport.Contains(e.Target.Name))
                    allUses.Add(new Use { Name = e.Target.Name, Pos = e.Target.HasPos ? e.Target.Pos : e.Pos });
            }

            // NPCs you clicked in places far apart (your companion follows you): never the cause of a quest tick
            var followers = new HashSet<string>(StringComparer.Ordinal);
            var npcSpots = new Dictionary<string, Vec3>(StringComparer.Ordinal);
            foreach (RecEvent e in events)
            {
                if (e.Kind != EvKind.NpcClick || e.Target == null || e.Target.Name.Length == 0)
                    continue;
                Vec3 at = e.Target.HasPos ? e.Target.Pos : e.Pos;
                Vec3 first;
                if (!npcSpots.TryGetValue(e.Target.Name, out first))
                    npcSpots[e.Target.Name] = at;
                else if (first.DistanceTo(at) > 25f)
                    followers.Add(e.Target.Name);
            }
            var questTitles = new Dictionary<ulong, string>();
            foreach (RecEvent e in events)
                if (e.QuestId != 0 && !string.IsNullOrEmpty(e.QuestName) && !questTitles.ContainsKey(e.QuestId))
                    questTitles[e.QuestId] = e.QuestName;
            var killedNames = new HashSet<string>(StringComparer.Ordinal);
            foreach (RecEvent e in events)
                if (e.Kind == EvKind.Kill && e.Target != null && e.Target.Name.Length > 0)
                    killedNames.Add(e.Target.Name);

            var steps = new List<Step>();
            var markers = new List<KeyValuePair<string, Vec3>>();
            var uses = new List<Use>();
            var consumed = new Dictionary<string, double>(StringComparer.Ordinal);
            var seen = new Dictionary<string, Vec3>(StringComparer.Ordinal);
            var kills = new List<Kill>();
            ObjRef talk = null;
            double talkAt = -1e9;
            double holoAt = -1e9;
            string item = null;
            double itemAt = -1e9;
            double rideAt = -1e9;
            double fightAt = -1e9;
            double castEndAt = -1e9;
            Step pendingRide = null;
            Vec3 rideFrom = default(Vec3);
            ObjRef pendingLift = null;
            string pendingDest = string.Empty;
            double liftOpenAt = -1e9;
            Vec3 itemPos = default(Vec3);
            string castItem = null; // a cast on nothing (maybe a mission item) and where it ended
            double castItemAt = -1e9;
            Vec3 castItemPos = default(Vec3);
            string npcClickName = null;
            Vec3 npcClickPos = default(Vec3);
            double npcClickAt = -1e9;
            Step lastWalk = null;
            var finalAt = new Dictionary<ulong, double>();
            double lastWalkAt = -1e9;
            int dark = 0, light = 0;
            var vendors = new Dictionary<string, Vec3>(StringComparer.Ordinal);
            double lastProgressAt = -1e9;
            ulong lastProgressQuest = 0;
            EvKind lastProgressKind = EvKind.Start;
            var stepText = new Dictionary<ulong, string>();
            var picked = new List<ulong>();
            var completedOrder = new List<ulong>();
            double bareCastAt = -1e9;
            Vec3 bareCastPos = default(Vec3);

            bool haveTrail = false;
            Vec3 lastTrail = default(Vec3);
            foreach (RecEvent e in events)
            {
                double t = e.Elapsed;
                if (pendingRide != null && !e.Pos.IsZero && e.Pos.DistanceTo(rideFrom) >= 3f)
                {
                    pendingRide.Gate = SideOf(rideFrom, e.Pos);
                    if (pendingDest.Length > 0 && pendingLift.HasPos)
                    {
                        pendingRide.Comment = "Elevator: " + pendingLift.Name + " to " + pendingDest;
                        pendingRide.Lines[0] = "<UseTransport TransporterName=\"" + A(pendingLift.Name) + "\" Type=\"Wonkavator\" Option=\"" + A(pendingDest) +
                                               "\" XYZ=\"" + X(pendingLift.Pos) + "\" />";
                    }
                    else
                    {
                        // the floor is not known: walk to where you came out and leave the lift to BuddyCron
                        pendingRide.Comment = "Elevator: " + pendingLift.Name + "";
                        pendingRide.Lines[0] = "<MoveTo QuestId=\"1\" Name=\"Off the " + A(pendingLift.Name) + "\" XYZ=\"" + X(e.Pos) + "\" />";
                    }
                    pendingRide = null;
                }
                // Follow your footsteps: a walk point every WalkSpacing metres; BuddyCron finds the way in between.
                if ((e.Kind == EvKind.ElevatorRide || e.Kind == EvKind.Loading || e.Kind == EvKind.Jump || e.Kind == EvKind.AreaChange) && !e.Pos.IsZero)
                {
                    haveTrail = true;
                    lastTrail = e.Pos; // the ride step takes you there; footsteps go on from the arrival
                }
                else if (e.Kind != EvKind.Start && e.Kind != EvKind.QuestLog && e.Kind != EvKind.Stop && !e.Pos.IsZero)
                {
                    if (!haveTrail)
                    {
                        haveTrail = true;
                        lastTrail = e.Pos;
                    }
                    else if (WalkSpacing > 0f && lastTrail.DistanceTo(e.Pos) >= WalkSpacing)
                    {
                        markers.Add(new KeyValuePair<string, Vec3>("Your path", e.Pos));
                        lastTrail = e.Pos;
                    }
                }
                switch (e.Kind)
                {
                    case EvKind.Marker:
                        if (e.Note.StartsWith(UndoNote, StringComparison.Ordinal))
                        {
                            if (uses.Count > 0)
                                uses.RemoveAt(uses.Count - 1); // undo hotkey: forget the last object click
                            break;
                        }
                        markers.Add(new KeyValuePair<string, Vec3>(e.Note, e.Pos));
                        break;
                    case EvKind.ObjectClick:
                    case EvKind.Cast:
                    {
                        ObjRef o = e.Target;
                        if (e.Kind == EvKind.Cast && (o == null || o.Name.Length == 0 || o.Name.StartsWith("#", StringComparison.Ordinal)) && !e.Pos.IsZero)
                        {
                            // a cast the game did not tie to an object (CZ-198 Biotoxin 1, Kolto 1): you stood right at it
                            bareCastAt = t;
                            bareCastPos = e.Pos;
                            // a cast on nothing that moves you far right after is a mission item too.
                            if (e.Option.Length > 0 && e.Option != "Loot" && !e.Option.EndsWith("...", StringComparison.Ordinal) && !IsTravelAbility(e.Option))
                            {
                                castItem = e.Option;
                                castItemAt = t;
                                castItemPos = e.Pos;
                            }
                        }
                        if (o == null || o.Kind != ObjKind.Placeable || o.Name.Length == 0 || o.Name.StartsWith("#", StringComparison.Ordinal) || transport.Contains(o.Name))
                            break;
                        Vec3 p = o.HasPos ? o.Pos : e.Pos;
                        string key = X(p);
                        seen[o.Name] = p;
                        double when;
                        if (e.Kind == EvKind.ObjectClick && consumed.TryGetValue(key, out when) && t - when <= 30)
                            break; // a second click on an object already used (no new cast on it)
                        if (e.Kind == EvKind.ObjectClick && t - castEndAt <= 1.5 && uses.Count > 0 && uses[uses.Count - 1].Name != o.Name)
                            break; // a stray click right as a cast on another object ended (CZ-198 Kolto after the last pod)
                        if (e.Kind == EvKind.Cast)
                            castEndAt = t;
                        if (uses.Count > 0 && X(uses[uses.Count - 1].Pos) == key)
                        {
                            uses[uses.Count - 1].At = t; // the click and its cast are one use
                            if (e.Kind == EvKind.Cast)
                                uses[uses.Count - 1].Cast = true;
                            break;
                        }
                        uses.Add(new Use { Name = o.Name, Pos = p, At = t, Cast = e.Kind == EvKind.Cast, Stand = e.Pos });
                        break;
                    }
                    case EvKind.ConvoStart:
                        if (e.Note == How.HolocomCall)
                            holoAt = t;
                        else if (e.Target != null && e.Target.Name.Length > 0)
                        {
                            talk = e.Target;
                            talkAt = t;
                        }
                        break;
                    case EvKind.QuestItem:
                        if (e.Option.Length > 0)
                        {
                            item = e.Option;
                            itemAt = t;
                            itemPos = e.Pos;
                        }
                        break;
                    case EvKind.Loading:
                        // handled with the jump / area change it causes (below)
                        if (e.HasFrom && item != null && t - itemAt <= 30)
                            goto case EvKind.Jump;
                        break;
                    case EvKind.NpcClick:
                        if (e.Target != null && e.Target.Name.Length > 0 && !string.Equals(e.Target.Toughness, "companion", StringComparison.OrdinalIgnoreCase))
                        {
                            npcClickName = e.Target.Name;
                            npcClickPos = e.Target.HasPos ? e.Target.Pos : e.Pos;
                            npcClickAt = t;
                        }
                        break;
                    case EvKind.ConvoChoice:
                        if (!e.OptionGuessed && e.Option.EndsWith(" dark", StringComparison.Ordinal))
                            dark++;
                        else if (!e.OptionGuessed && e.Option.EndsWith(" light", StringComparison.Ordinal))
                            light++;
                        break;
                    case EvKind.ElevatorOpen:
                    case EvKind.ElevatorRide:
                    {
                        // Take the elevator you took.
                        ObjRef w = e.Target;
                        string dest = e.Kind == EvKind.ElevatorRide ? e.Option : string.Empty;
                        if (dest.Length == 0 && w != null && w.Destinations != null && w.Destinations.Length == 2 && w.Floor >= 1 && w.Floor <= 2)
                            dest = w.Destinations[2 - w.Floor]; // two floors: the other one
                        rideAt = t;
                        if (e.Kind == EvKind.ElevatorRide && w != null && pendingLift != null && w.Name == pendingLift.Name && t - liftOpenAt <= 60)
                        {
                            // the window you opened, now ridden: that step already covers it (just take the floor if new)
                            if (pendingRide != null && dest.Length > 0 && pendingDest.Length == 0)
                                pendingDest = dest;
                            break;
                        }
                        liftOpenAt = t;
                        if (w != null && w.Name.Length > 0)
                        {
                            // walk points so far come first
                            if (markers.Count > 0)
                            {
                                var before = new Step { Kind = "Route", Comment = "Your route" };
                                AddRoute(before, markers);

                                steps.Add(before);
                                markers.Clear();
                            }
                            // The ride is its own step, not tied to one quest step.
                            var ride = new Step { Kind = "Ride", Comment = "Elevator: " + w.Name };
                            ride.Lines.Add(string.Empty); // written when you come out (below)
                            steps.Add(ride);
                            pendingRide = ride;
                            pendingLift = w;
                            pendingDest = dest;
                            rideFrom = e.HasStand ? e.Stand : (e.Kind == EvKind.ElevatorOpen ? e.Pos : e.FromPos);
                        }
                        break;
                    }
                    case EvKind.TaxiStart:
                    case EvKind.TaxiEnd:
                    case EvKind.ShipTravel:
                        rideAt = t;
                        break;
                    case EvKind.AreaChange:
                    case EvKind.Jump:
                        // A mission item that moved you.
                        if ((item == null || t - itemAt > 30) && castItem != null && t - castItemAt <= 3 && e.Kind == EvKind.Jump)
                        {
                            item = castItem;
                            itemAt = castItemAt;
                            itemPos = castItemPos;
                        }
                        castItem = null;
                        if (item != null && t - itemAt <= 30 && e.HasFrom && e.FromPos.DistanceTo(e.Pos) >= 30f && t - rideAt > 5)
                        {
                            FlushRoute(steps, markers);
                            // Runs from wherever you are.
                            string away = Fmt.Format("(((Me.Position.X - ({0})) ** 2 + (Me.Position.Z - ({1})) ** 2) &gt; 10000)",
                                                     Fmt.F3(e.Pos.X), Fmt.F3(e.Pos.Z));
                            // An old recording only knew the cast "Heroic Transport".
                            string useName = item == "Heroic Transport" ? HeroicMark : item;
                            string pyName = useName.Replace("\\", "\\\\").Replace("'", "\\'");
                            string have = "(any(i.Name == '" + pyName + "' for i in Me.QuestItems) or any(i.Name == '" + pyName + "' for i in Me.Backpack))";
                            string shortHave = "(any(i.Name == 'Heroic Transport' for i in Me.QuestItems) or any(i.Name == 'Heroic Transport' for i in Me.Backpack))";
                            bool heroic = useName.StartsWith("Heroic Transport: ", StringComparison.Ordinal);
                            // the whole step (waits too) only runs when a shuttle can actually be used from here
                            var hop = new Step { Kind = "Ride", Comment = "Mission item: " + useName, Gate = away + " and " + A(heroic ? "(" + have + " or " + shortHave + ")" : have) };
                            string where = "<Hotspots><Hotspot Name=\"Where you used it\" XYZ=\"" + X(itemPos.IsZero ? e.FromPos : itemPos) + "\" /></Hotspots>";
                            string cond = away + " and " + A(have);
                            hop.Lines.Add("<If Condition=\"" + cond + "\">");
                            hop.Lines.Add("<UseItem ItemName=\"" + A(useName) + "\" Condition=\"" + cond + "\" WaitTime=\"3000\" Range=\"100000\">" + where + "</UseItem>");
                            hop.Lines.Add("<WaitTimer QuestId=\"1\" WaitTime=\"10\" />");
                            hop.Lines.Add("</If>");
                            if (heroic)
                            {
                                // The Korriban way: UseItem "Heroic Transport" took the shuttle there.
                                string shortCond = away + " and " + A(shortHave);
                                hop.Lines.Add("<If Condition=\"" + shortCond + "\">");
                                hop.Lines.Add("<UseItem ItemName=\"Heroic Transport\" Condition=\"" + shortCond + "\" WaitTime=\"3000\" Range=\"100000\">" + where + "</UseItem>");
                                hop.Lines.Add("<WaitTimer QuestId=\"1\" WaitTime=\"10\" />");
                                hop.Lines.Add("</If>");
                            }                            steps.Add(hop);
                            item = null;
                            rideAt = t;
                            haveTrail = true;
                            lastTrail = e.Pos;
                            break;
                        }
                        // a phase door / doorway you went through.
                        if (t - rideAt > 20 && e.HasFrom && !e.Note.StartsWith(How.Revived, StringComparison.Ordinal))
                        {
                            markers.Add(new KeyValuePair<string, Vec3>("Before the " + (e.Kind == EvKind.AreaChange ? "area change" : "door / phase"), e.FromPos));
                            markers.Add(new KeyValuePair<string, Vec3>("Came out here", e.Pos));
                        }
                        break;
                    case EvKind.CombatStart:
                        fightAt = t;
                        break;
                    case EvKind.Kill:
                        if (e.Note.Length == 0 && e.Target != null)
                        {
                            var k = new Kill { Name = e.Target.Name, Pos = e.Target.HasPos ? e.Target.Pos : e.Pos, At = t };
                            kills.Add(k);
                            if (lastWalk != null && t - lastWalkAt <= 2 && steps.Contains(lastWalk))
                            {
                                // the count that ticked just before was this kill: fight it there instead of walking
                                lastWalk.Kind = "Grind";
                                lastWalk.Kills = new List<Kill> { k };
                                lastWalk.Lines.RemoveAll(l => l.StartsWith("<MoveTo", StringComparison.Ordinal) && l.Contains("Where it ticked"));
                            }
                            lastWalk = null;
                        }
                        break;
                    case EvKind.QuestAdded:
                    {
                        uses.Clear(); // the click on the giver / board was the pick-up
                        if (e.QuestHidden || e.QuestId == 0)
                            break;
                        string q = Fmt.Hex(e.QuestId);
                        picked.Add(e.QuestId);
                        var s = new Step { Kind = "Pickup", Gate = "(not HasQuest(" + q + ")) and (not IsQuestComplete(" + q + "))", Comment = "Pick up " + e.QuestName };
                        if (e.Target != null && e.Target.Name.Length > 0)
                        {
                            Vec3 gp = e.Target.HasPos ? e.Target.Pos : e.Pos;
                            s.Lines.Add("<PickUpQuest QuestName=\"" + A(e.QuestName) + "\" QuestId=\"" + q + "\"" + (e.Target.Kind == ObjKind.Placeable ? " SearchRadius=\"20\"" : string.Empty) +
                                        " UseRange=\"20\" GiverName=\"" + A(e.Target.Name) + "\" XYZ=\"" + X(gp) + "\" />");
                        }
                        else
                        {
                            s.Lines.Add("<!-- " + Fmt.XmlComment(e.QuestName + " - comes by itself, no giver.") + " -->");
                        }
                        steps.Add(s);
                        break;
                    }
                    case EvKind.QuestTask:
                    case EvKind.QuestStep:
                    {
                        if (e.QuestHidden || e.QuestId == 0)
                            break;
                        if (e.Kind == EvKind.QuestTask && e.Text.StartsWith("Complete ", StringComparison.OrdinalIgnoreCase))
                            break; // a weekly's "Complete X" ticks by itself
                        string q = Fmt.Hex(e.QuestId);
                        bool isCount = e.Kind == EvKind.QuestTask && e.Max > 0;
                        int task = e.TaskIndex >= 0 ? e.TaskIndex : 0;
                        string gate, what;
                        if (isCount)
                        {
                            gate = Fmt.Format("HasQuest({0}) and not IsTaskValueGreaterThan({0}, {1}, {2}, {3})", q, e.Step, task, e.Count > 0 ? e.Count - 1 : 0);
                            what = Fmt.Format("{0}: {1} ({2}/{3})", e.QuestName, e.Text, e.Count, e.Max);
                        }
                        else
                        {
                            ulong ob = e.HasOldStep ? e.OldBranch : e.Branch;
                            ulong os = e.HasOldStep ? e.OldStep : e.Step;
                            gate = Fmt.Format("HasQuest({0}) and not IsBranchStepComplete({0}, {1}, {2})", q, ob, os);
                            what = Fmt.Format("{0}: step {2} done{3}", e.QuestName, ob, os, e.Text.Length > 0 ? " (next: " + e.Text + ")" : string.Empty);
                        }
                        // the same moment: another quest counting the same action, or this quest's task finishing its step
                        if (e.Kind == EvKind.QuestStep || (isCount && e.Count >= e.Max))
                            finalAt[e.QuestId] = t; // this tick finished the step / count
                        bool sameMoment = t - lastProgressAt <= 1.0;
                        if (sameMoment && (lastProgressQuest != e.QuestId || lastProgressKind == EvKind.QuestTask)) // another quest, or a second count / the step of this quest ticking for the same action (Section X Hyperbiology ticks two counts per sample)
                        {
                            lastProgressAt = t;
                            lastProgressQuest = e.QuestId;
                            lastProgressKind = e.Kind;
                            if (e.Text.Length > 0)
                                stepText[e.QuestId] = e.Text;
                            break;
                        }
                        lastProgressAt = t;
                        lastProgressQuest = e.QuestId;
                        lastProgressKind = e.Kind;
                        // a step change carries the NEXT step's text: match objects against the step that just finished
                        string doneText;
                        if (e.Kind != EvKind.QuestStep || !stepText.TryGetValue(e.QuestId, out doneText))
                            doneText = e.Text;
                        if (e.Text.Length > 0)
                            stepText[e.QuestId] = e.Text;
                        // How an object is used, like the tested profiles.
                        string useIds = null;
                        if (isCount && e.Count >= e.Max)
                            useIds = Fmt.Format(" QuestId=\"{0}\" BranchId=\"{1}\" StepId=\"{2}\" TaskId=\"{3}\"", q, e.Branch, e.Step, task);
                        else if (!isCount)
                            useIds = Fmt.Format(" QuestId=\"{0}\" BranchId=\"{1}\" StepId=\"{2}\"", q, e.HasOldStep ? e.OldBranch : e.Branch, e.HasOldStep ? e.OldStep : e.Step);

                        var lines = new List<string>();
                        if (markers.Count > 0)
                        {
                            // Walk points are their own step.
                            var route = new Step { Kind = "Route", Comment = "Your route" };
                            AddRoute(route, markers);
                            steps.Add(route);
                            markers.Clear();
                        }

                        // your object uses since the last progress; the ones this task names go here, the others wait
                        List<string> ow = Words(doneText);
                        var recent = uses.FindAll(u => t - u.At <= (isCount ? 30 : 180)); // a puzzle can take a few minutes
                        var named = recent.FindAll(u => Shares(u.Name, ow));
                        bool keepRest = false;
                        List<Use> take = named.Count > 0 ? named : recent;
                        // a kill right before the tick and no object the objective names.
                        var spawners = new List<Use>();
                        if (named.Count == 0 && kills.Count > 0 && t - kills[kills.Count - 1].At <= 3 && (take.Count == 0 || t - take[take.Count - 1].At > 3))
                        {
                            // ...or an object you really used.
                            take = take.FindAll(u => kills.Exists(k => k.Pos.DistanceTo(u.Pos) <= (u.Cast ? 3f : 1f)) ||
                                                     (u.Cast && u.At <= fightAt + 1 && fightAt - u.At <= 20));
                            foreach (Use u in take)
                                if (!kills.Exists(k => k.Pos.DistanceTo(u.Pos) <= 3f))
                                    spawners.Add(u);
                            // one count, one object: the one the mob that just died came out of (pod 1 -> droid 1)
                            if (isCount && take.Count > 1)
                            {
                                Vec3 kp = kills[kills.Count - 1].Pos;
                                take.Sort((a, b) => a.Pos.DistanceTo(kp).CompareTo(b.Pos.DistanceTo(kp)));
                                keepRest = true;
                                take = new List<Use> { take[0] };
                            }
                        }
                        // A step finished after several objects.
                        if (!isCount && take.Count > 1)
                        {
                            var seq = new List<Use>();
                            foreach (Use u in take)
                                if (seq.Count == 0 || X(seq[seq.Count - 1].Pos) != X(u.Pos))
                                    seq.Add(u);
                            for (int si = 0; si < seq.Count - 1; si++)
                                if (!spawners.Contains(seq[si]))
                                    spawners.Add(seq[si]);
                            foreach (Use u in take)
                                if (!seq.Contains(u))
                                    uses.Remove(u);
                            take = seq;
                        }
                        // Every use in the order you did it, tied to the quest so it can never loop.
                        string countIds = isCount
                            ? Fmt.Format(" QuestId=\"{0}\" BranchId=\"{1}\" StepId=\"{2}\" TaskId=\"{3}\" TaskValue=\"{4}\"", q, e.Branch, e.Step, task, e.Count > 0 ? e.Count - 1 : 0)
                            : useIds;
                        foreach (Use u in take)
                        {
                            if (spawners.Contains(u))
                            {
                                // the object only starts the fight.
                                if (!u.Stand.IsZero && u.Stand.DistanceTo(u.Pos) > 1.5f && u.Stand.DistanceTo(u.Pos) < 10f)
                                    lines.Add("<MoveTo QuestId=\"1\" Name=\"Stand for " + A(u.Name) + "\" XYZ=\"" + X(u.Stand) + "\" />");
                                lines.Add("<Interact QuestId=\"" + q + "\" Name=\"" + A(u.Name) + "\" XYZ=\"" + X(u.Pos) + "\" />");
                                consumed[X(u.Pos)] = t;
                                uses.Remove(u);
                                continue;
                            }
                            lines.AddRange(UseAt(u.Name, u.Pos, u.Stand, countIds));
                            consumed[X(u.Pos)] = t;
                            uses.Remove(u);
                        }
                        if (named.Count == 0 && !keepRest)
                            uses.Clear();

                        bool killCause = kills.Count > 0 && t - kills[kills.Count - 1].At <= 3;
                        // an object use that ended within 3 s of the tick did it, even if a mob died at the same moment
                        if (take.Count > 0 && t - take[take.Count - 1].At <= 3)
                            killCause = false;
                        if (killCause)
                        {
                            // a boss step keeps every mob from the whole fight, in the order you killed them.
                            double from = Math.Min(fightAt, t - 3);
                            var use = kills.FindAll(k => isCount || k.At >= from - 1);
                            Step prev = steps.Count > 0 ? steps[steps.Count - 1] : null;
                            if (isCount && lines.Count == 0 && prev != null && prev.Kind == "Grind" && prev.Quest == e.QuestId && prev.Task == e.TaskIndex)
                            {
                                prev.Gate = gate; // the same kill count going on: its stop point moves up
                                prev.Comment = what;
                                prev.Kills.AddRange(use);
                            }
                            else
                            {
                                var g = new Step { Kind = "Grind", Gate = gate, Comment = what, Quest = e.QuestId, Task = e.TaskIndex, Kills = use };
                                g.Lines.AddRange(lines);
                                steps.Add(g);
                            }
                            kills.Clear();
                            break;
                        }
                        // kept for a count you got by looting what the mobs dropped (the tick comes after the loot, not the kill)
                        List<Kill> lootKills = kills.FindAll(k => t - k.At <= 20);
                        kills.Clear();
                        if (item != null && t - itemAt <= 20)
                        {
                            // a quest item you used right before (UseItem fires it at the spot you used it)
                            string itemIds = isCount
                                ? Fmt.Format(" StepId=\"{0}\" TaskId=\"{1}\"", e.Step, task)
                                : Fmt.Format(" BranchId=\"{0}\" StepId=\"{1}\"", e.HasOldStep ? e.OldBranch : e.Branch, e.HasOldStep ? e.OldStep : e.Step);
                            lines.Add("<UseItem QuestId=\"" + q + "\"" + itemIds + " ItemName=\"" + A(item) + "\" WaitTime=\"3000\" XYZ=\"" + X(e.Pos) + "\">" +
                                      "<Hotspots><Hotspot Name=\"Where you used it\" XYZ=\"" + X(e.Pos) + "\" /></Hotspots></UseItem>");
                            item = null;
                            AddStep(steps, "Item", gate, what, lines, e.QuestId);
                            break;
                        }
                        if (take.Count > 0)
                        {
                            AddStep(steps, "Use", gate, what, lines, e.QuestId);
                            break;
                        }
                        if (t - holoAt <= 20)
                        {
                            lines.Add("<AnswerHolocomCall QuestName=\"" + A(e.QuestName) + "\" QuestId=\"" + q + "\" />");
                            holoAt = -1e9;
                            AddStep(steps, "Holocom", gate, what, lines, e.QuestId);
                            break;
                        }
                        if (talk != null && t - talkAt <= 20)
                        {
                            lines.Add("<" + (talk.Kind == ObjKind.Placeable ? "Interact" : "TalkTo") + " QuestId=\"" + q + "\" Name=\"" + A(talk.Name) + "\" WaitTime=\"5\" XYZ=\"" +
                                      X(talk.HasPos ? talk.Pos : e.Pos) + "\" />");
                            talk = null;
                            AddStep(steps, "Talk", gate, what, lines, e.QuestId);
                            break;
                        }
                        if (isCount && lootKills.Count > 0)
                        {
                            // Story quests "Collect 6 datapads" style: you killed, then looted, then it ticked.
                            var lg = new Step { Kind = "Grind", Gate = gate, Comment = what + " (kill and loot)", Quest = e.QuestId, Task = e.TaskIndex, Kills = lootKills };
                            lg.Lines.AddRange(lines);
                            steps.Add(lg);
                            break;
                        }
                        if (isCount && npcClickName != null && t - npcClickAt <= 6 && killedNames.Contains(npcClickName))
                        {
                            // you looted the body of a mob you had killed.
                            var lk = new Step { Kind = "Grind", Gate = gate, Comment = what + " (kill and loot)", Quest = e.QuestId, Task = e.TaskIndex,
                                                Kills = new List<Kill> { new Kill { Name = npcClickName, Pos = npcClickPos, At = t } } };
                            lk.Lines.AddRange(lines);
                            steps.Add(lk);
                            npcClickName = null;
                            break;
                        }
                        // a cast with no object just before the tick.
                        if (t - bareCastAt <= 3)
                        {
                            string castName = null;
                            foreach (Use a in allUses)
                            {
                                if (Shares(a.Name, ow))
                                {
                                    castName = a.Name;
                                    break;
                                }
                            }
                            if (castName != null)
                            {
                                lines.Add("<UseObject ObjectName=\"" + A(castName) + "\"" + countIds + " Radius=\"20\" UseRange=\"20\" IgnoreLOS=\"True\" WaitTime=\"3000\" BlacklistDuration=\"5\" XYZ=\"" + X(bareCastPos) + "\" />");
                                bareCastAt = -1e9;
                                AddStep(steps, "Use", gate, what, lines, e.QuestId);
                                break;
                            }
                        }
                        // no use seen, but the task names an object you used before (a respawning container): use it again
                        string again = null;
                        foreach (string n in seen.Keys)
                        {
                            if (Shares(n, ow))
                            {
                                again = n;
                                break;
                            }
                        }
                        Vec3 againPos = again != null ? seen[again] : default(Vec3);
                        if (again == null)
                        {
                            // The game did not say which object your cast hit.
                            float best = 25f;
                            foreach (Use a in allUses)
                            {
                                float d = a.Pos.DistanceTo(e.Pos);
                                if (d < best && Shares(a.Name, ow))
                                {
                                    best = d;
                                    again = a.Name;
                                    againPos = a.Pos;
                                }
                            }
                        }
                        if (again != null)
                        {
                            lines.AddRange(UseAt(again, againPos, default(Vec3), countIds));
                            AddStep(steps, "Use", gate, what, lines, e.QuestId);
                            break;
                        }
                        if (npcClickName != null && t - npcClickAt <= 30 && !killedNames.Contains(npcClickName) && !followers.Contains(npcClickName))
                        {
                            // you clicked an NPC (no conversation) and the count went up a bit later (Black Hole 'Identify.
                            lines.Add("<TalkTo QuestId=\"" + q + "\" Name=\"" + A(npcClickName) + "\" WaitTime=\"5\" XYZ=\"" + X(npcClickPos) + "\" />");
                            npcClickName = null;
                            AddStep(steps, "Talk", gate, what, lines, e.QuestId);
                            break;
                        }
                        lines.Add("<MoveTo QuestId=\"" + q + "\" Name=\"Where it ticked\" XYZ=\"" + X(e.Pos) + "\" />");
                        AddStep(steps, "Walk", gate, what, lines, e.QuestId);
                        if (isCount)
                        {
                            // the count can tick a moment BEFORE the game reports the kill.
                            lastWalk = steps[steps.Count - 1];
                            lastWalkAt = t;
                        }
                        break;
                    }
                    case EvKind.QuestRemoved:
                    {
                        // picked up and gone again without any progress.
                        ulong gone = e.QuestId;
                        if (gone != 0 && !steps.Exists(st => st.Quest == gone && st.Kind != "Pickup"))
                        {
                            steps.RemoveAll(st => st.Kind == "Pickup" && st.Gate != null && st.Gate.Contains(Fmt.Hex(gone)));
                            picked.Remove(gone);
                        }
                        break;
                    }
                    case EvKind.QuestCompleted:
                    {
                        if (e.QuestHidden || e.QuestId == 0)
                            break;
                        string q = Fmt.Hex(e.QuestId);
                        // Finished by your last kill or use, with no count tick in between.
                        double fin;
                        bool ticked = finalAt.TryGetValue(e.QuestId, out fin) && t - fin <= 3.0; // a finishing tick ~1.2 s before the reward window
                        if (!ticked && !(talk != null && t - talkAt <= 20))
                        {
                            string doneGate = "HasQuest(" + q + ") and not IsQuestComplete(" + q + ")";
                            Use lastUse = uses.Count > 0 && t - uses[uses.Count - 1].At <= 3 ? uses[uses.Count - 1] : null;
                            if (kills.Count > 0 && t - kills[kills.Count - 1].At <= 3 && (lastUse == null || lastUse.At < kills[kills.Count - 1].At))
                            {
                                double from = Math.Min(fightAt, t - 3);
                                var g = new Step { Kind = "Grind", Gate = doneGate, Comment = e.QuestName + ": last fight", Quest = e.QuestId,
                                                   Kills = kills.FindAll(k => k.At >= from - 1) };
                                steps.Add(g);
                                kills.Clear();
                            }
                            else if (lastUse != null)
                            {
                                var u = new Step { Kind = "Use", Gate = doneGate, Comment = e.QuestName + ": last click", Quest = e.QuestId };
                                u.Lines.AddRange(UseAt(lastUse.Name, lastUse.Pos, lastUse.Stand, " QuestId=\"" + q + "\""));
                                steps.Add(u);
                                uses.Remove(lastUse);
                            }
                        }
                        var s = new Step { Kind = "Complete", Quest = e.QuestId, Comment = "Reward: " + e.QuestName };
                        // Handed in to someone you were talking to.
                        ObjRef by = null;
                        if (talk != null && t - talkAt <= 20)
                            by = talk;
                        else if (e.Target != null && e.Target.Name.Length > 0 && e.Note.IndexOf("clicked", StringComparison.OrdinalIgnoreCase) < 0 &&
                                 e.Note.IndexOf("talk", StringComparison.OrdinalIgnoreCase) >= 0)
                            by = e.Target;
                        if (by != null)
                        {
                            s.Gate = "HasQuest(" + q + ") and not IsQuestComplete(" + q + ")";
                            s.Quest = e.QuestId;
                            s.Lines.Add("<TurnInQuest QuestName=\"" + A(e.QuestName) + "\" QuestId=\"" + q + "\"" + (by.Kind == ObjKind.Placeable ? " SearchRadius=\"20\" UseRange=\"20\"" : string.Empty) +
                                        " TurnInName=\"" + A(by.Name) + "\" XYZ=\"" + X(by.HasPos ? by.Pos : e.Pos) + "\" />");
                        }
                        // BuddyCron only takes a reward that is already up.
                        if (s.Gate == null)
                            s.Gate = "HasQuest(" + q + ") and not IsQuestComplete(" + q + ")";
                        s.Lines.Add("<WaitTimer QuestId=\"1\" WaitTime=\"5\" />");
                        s.Lines.Add("<CompleteQuest QuestId=\"" + q + "\" />");
                        steps.Add(s);
                        if (!completedOrder.Contains(e.QuestId))
                            completedOrder.Add(e.QuestId);
                        break;
                    }
                    case EvKind.InteractionOpen:
                        // a vendor you used: the profile's Vendors list, so the bot repairs / sells where you did
                        if (e.Option == "Vendor" && e.Target != null && e.Target.Name.Length > 0 && e.Target.HasPos && !vendors.ContainsKey(e.Target.Name))
                            vendors[e.Target.Name] = e.Target.Pos;
                        break;
                }
            }

            if (pendingRide != null)
                steps.Remove(pendingRide); // the recording ended before you came out of the lift
            if (trace != null)
            {
                FillTrace(steps, trace);
                return string.Empty;
            }
            // Old recordings: name each Heroic Transport after the heroic you did next.
            for (int i = 0; i < steps.Count; i++)
            {
                if (steps[i].Kind != "Ride" || !steps[i].Comment.Contains(HeroicMark))
                    continue;
                string mission = null;
                for (int j = i + 1; j < steps.Count && mission == null; j++)
                {
                    string title;
                    if (steps[j].Quest != 0 && questTitles.TryGetValue(steps[j].Quest, out title) && title.StartsWith("[HEROIC", StringComparison.OrdinalIgnoreCase))
                    {
                        int close = title.IndexOf(']');
                        mission = (close >= 0 ? title.Substring(close + 1) : title).Trim();
                    }
                }
                string full = mission != null && mission.Length > 0 ? "Heroic Transport: " + mission : "Heroic Transport";
                steps[i].Comment = steps[i].Comment.Replace(HeroicMark, full);
                if (steps[i].Gate != null)
                    steps[i].Gate = steps[i].Gate.Replace("'" + HeroicMark + "'", "'" + A(full.Replace("\\", "\\\\").Replace("'", "\\'")) + "'");
                for (int k = 0; k < steps[i].Lines.Count; k++)
                    steps[i].Lines[k] = steps[i].Lines[k].Replace("'" + HeroicMark + "'", "'" + A(full.Replace("\\", "\\\\").Replace("'", "\\'")) + "'")
                                                         .Replace(HeroicMark, A(full));
            }
            return Render(steps, picked, profileName, fileName, recordingName, dark > light ? "Dark" : (light > dark ? "Light" : null), vendors, completedOrder);
        }

        /// <summary>Walk points collected so far become a route step before what comes next.</summary>
        private static void FlushRoute(List<Step> steps, List<KeyValuePair<string, Vec3>> markers)
        {
            if (markers.Count == 0)
                return;
            var route = new Step { Kind = "Route", Comment = "Your route" };
            AddRoute(route, markers);
            steps.Add(route);
            markers.Clear();
        }

        /// <summary>Writes walk points as route lines (lift rides become UseTransport).</summary>
        private static void AddRoute(Step route, List<KeyValuePair<string, Vec3>> markers)
        {
            foreach (KeyValuePair<string, Vec3> m in markers)
            {
                if (m.Key.StartsWith(RideKey, StringComparison.Ordinal))
                {
                    string[] wd = m.Key.Substring(RideKey.Length).Split('|');
                    route.Lines.Add("<UseTransport TransporterName=\"" + wd[0] + "\" Type=\"Wonkavator\" Option=\"" + wd[1] + "\" XYZ=\"" + X(m.Value) + "\" />");
                }
                else
                    route.Lines.Add("<MoveTo QuestId=\"1\" Name=\"" + A(m.Key) + "\" XYZ=\"" + X(m.Value) + "\" />");
            }
        }

        private static string LinkedUse(string name, Vec3 pos, string ids)
        {
            return LinkedUse(name, pos, ids, 20);
        }

        // BlacklistDuration 5: a use a fight cut short is tried again a few seconds later instead of after 30.
        private static string LinkedUse(string name, Vec3 pos, string ids, int useRange)
        {
            return "<UseObject ObjectName=\"" + A(name) + "\"" + ids + " UseRange=\"" + useRange.ToString(CultureInfo.InvariantCulture) +
                   "\" IgnoreLOS=\"True\" WaitTime=\"3000\" BlacklistDuration=\"5\" XYZ=\"" + X(pos) + "\" />";
        }

        /// <summary>One object use.</summary>
        private static List<string> UseAt(string name, Vec3 pos, Vec3 stand, string ids)
        {
            var l = new List<string>();
            float d = stand.IsZero ? 0f : stand.DistanceTo(pos);
            if (!stand.IsZero && (d > 1.5f || Math.Abs(stand.Y - pos.Y) > 1f) && d < 10f)
            {
                l.Add("<MoveTo QuestId=\"1\" Name=\"Stand for " + A(name) + "\" XYZ=\"" + X(stand) + "\" />");
                l.Add(LinkedUse(name, pos, ids, Math.Max(20, (int)Math.Ceiling((d + 1f) * 10f))));
            }
            else
                l.Add(LinkedUse(name, pos, ids, 20));
            return l;
        }

        private static string OneUse(string name, Vec3 pos)
        {
            return "<UseObject ObjectName=\"" + A(name) + "\" QuestId=\"1\" IgnoreQuestRelation=\"True\" UseRange=\"20\" IgnoreLOS=\"True\" WaitTime=\"3000\" XYZ=\"" + X(pos) + "\" />";
        }

        private static void AddStep(List<Step> steps, string kind, string gate, string what, List<string> lines, ulong quest)
        {
            var s = new Step { Kind = kind, Gate = gate, Comment = what, Quest = quest };
            s.Lines.AddRange(lines);
            steps.Add(s);
        }

        private static string Render(List<Step> steps, List<ulong> picked, string profileName, string fileName, string recordingName, string side,
                                     Dictionary<string, Vec3> vendors, List<ulong> completedOrder)
        {
            var sb = new StringBuilder();
            const string nl = "\r\n";
            sb.Append("<Profile>").Append(nl);
            sb.Append("\t<!-- Made by Quest Recorder ").Append(QuestRecorderPlugin.Patch).Append(" - LethToxic. Recording: ").Append(Fmt.XmlComment(recordingName)).Append(" -->").Append(nl);
            string by = Fmt.OneLine(CreditName ?? string.Empty).Trim();
            if (by.Length > 0)
                sb.Append("\t<!-- Recorded by ").Append(Fmt.XmlComment(by.Length > 60 ? by.Substring(0, 60) : by)).Append(" -->").Append(nl);
            sb.Append("\t<Name>").Append(Fmt.XmlAttr(profileName)).Append("</Name>").Append(nl);
            if (side != null)
                sb.Append("\t<!-- You mostly picked ").Append(side.ToLowerInvariant()).Append(" replies. -->").Append(nl)
                  .Append("\t<ForceAlignment Type=\"").Append(side).Append("\" AutoSkip=\"True\" />").Append(nl);
            if (vendors.Count > 0)
            {
                sb.Append("\t<Vendors>").Append(nl);
                foreach (KeyValuePair<string, Vec3> v in vendors)
                    sb.Append("\t\t<Hotspot Name=\"").Append(A(v.Key)).Append("\" XYZ=\"").Append(X(v.Value)).Append("\" />").Append(nl);
                sb.Append("\t</Vendors>").Append(nl);
            }
            sb.Append(nl);
            sb.Append("\t<Questing>").Append(nl);
            // Route steps: walk them only while the step they lead to is still to do.
            for (int i = 0; i < steps.Count; i++)
            {
                if (steps[i].Kind == "Ride")
                {
                    // ride while on the near side and any quest with a step after the ride is unfinished
                    var open = new List<string>();
                    var qs = new HashSet<ulong>();
                    for (int j = i + 1; j < steps.Count; j++)
                    {
                        ulong q = steps[j].Quest;
                        if (q != 0 && qs.Add(q))
                            open.Add(Fmt.Format("(HasQuest({0}) and not IsQuestComplete({0}))", Fmt.Hex(q)));
                    }
                    if (open.Count == 0)
                        steps[i].Kind = "Skip";
                    else
                        steps[i].Gate = steps[i].Gate + " and (" + string.Join(" or ", open) + ")";
                }
            }
            for (int i = 0; i < steps.Count; i++)
            {
                if (steps[i].Kind != "Route")
                    continue;
                string next = null;
                for (int j = i + 1; j < steps.Count && next == null; j++)
                {
                    Step n = steps[j];
                    if (n.Gate != null && n.Kind != "Pickup" && n.Kind != "Route" && n.Kind != "Skip")
                        next = n.Gate;
                }
                steps[i].Gate = next;
                if (next == null)
                    steps[i].Kind = "Skip";
            }
            foreach (Step s in steps)
            {
                if (s.Kind == "Skip")
                    continue;
                sb.Append("\t\t<!-- ").Append(Fmt.XmlComment(s.Comment)).Append(" -->").Append(nl);
                if (s.Kind == "Grind")
                {
                    var anchors = new List<Kill>();
                    var mobs = new List<string>();
                    foreach (Kill k in s.Kills)
                    {
                        if (!mobs.Contains(k.Name))
                            mobs.Add(k.Name);
                        bool near = false;
                        foreach (Kill a in anchors)
                        {
                            if (a.Pos.DistanceTo(k.Pos) <= 6f)
                            {
                                near = true;
                                break;
                            }
                        }
                        if (!near && anchors.Count < 8)
                            anchors.Add(k);
                    }
                    sb.Append("\t\t<If Condition=\"").Append(s.Gate).Append("\">").Append(nl);
                    foreach (string l in s.Lines)
                        sb.Append("\t\t\t").Append(l).Append(nl);
                    sb.Append("\t\t\t<Grind While=\"").Append(s.Gate).Append("\">").Append(nl);
                    sb.Append("\t\t\t\t<GrindArea Name=\"").Append(A(s.Comment)).Append("\">").Append(nl);
                    sb.Append("\t\t\t\t\t<MinLevel>1</MinLevel>").Append(nl).Append("\t\t\t\t\t<MaxLevel>100</MaxLevel>").Append(nl).Append("\t\t\t\t\t<Mobs>");
                    foreach (string m in mobs)
                        sb.Append("<Mob>").Append(A(m)).Append("</Mob>");
                    sb.Append("</Mobs>").Append(nl).Append("\t\t\t\t\t<Hotspots>").Append(nl);
                    foreach (Kill a in anchors)
                        sb.Append("\t\t\t\t\t\t<Hotspot Name=\"").Append(A(a.Name)).Append("\" XYZ=\"").Append(X(a.Pos)).Append("\" />").Append(nl);
                    sb.Append("\t\t\t\t\t</Hotspots>").Append(nl).Append("\t\t\t\t</GrindArea>").Append(nl).Append("\t\t\t</Grind>").Append(nl).Append("\t\t</If>").Append(nl);
                }
                else if (s.Gate != null)
                {
                    sb.Append("\t\t<If Condition=\"").Append(s.Gate).Append("\">").Append(nl);
                    foreach (string l in s.Lines)
                        sb.Append("\t\t\t").Append(l).Append(nl);
                    sb.Append("\t\t</If>").Append(nl);
                }
                else
                {
                    foreach (string l in s.Lines)
                        sb.Append("\t\t").Append(l).Append(nl);
                }
            }
            if (completedOrder.Count > 0)
            {
                // last check: any reward window still open (a fight can hold one back; the weekly's comes last)
                sb.Append("\t\t<!-- Grab any rewards still waiting -->").Append(nl);
                sb.Append("\t\t<WaitTimer QuestId=\"1\" WaitTime=\"5\" />").Append(nl);
                foreach (ulong q in completedOrder)
                    sb.Append("\t\t<CompleteQuest QuestId=\"").Append(Fmt.Hex(q)).Append("\" />").Append(nl);
            }
            if (picked.Count > 0 && fileName.Length > 0)
            {
                // a use that did not register leaves its quest unfinished: go round again (finished steps are skipped)
                var conds = new List<string>();
                foreach (ulong q in picked)
                {
                    string h = Fmt.Hex(q);
                    string c = "(HasQuest(" + h + ") and not IsQuestComplete(" + h + "))";
                    if (!conds.Contains(c))
                        conds.Add(c);
                }
                sb.Append("\t\t<!-- Not finished? Go round again (done steps get skipped) -->").Append(nl);
                sb.Append("\t\t<If Condition=\"").Append(string.Join(" or ", conds)).Append("\">").Append(nl);
                sb.Append("\t\t\t<WaitTimer QuestId=\"1\" WaitTime=\"3\" />").Append(nl);
                sb.Append("\t\t\t<LoadProfile Path=\"").Append(A(fileName)).Append("\" />").Append(nl);
                sb.Append("\t\t</If>").Append(nl);
            }
            sb.Append("\t</Questing>").Append(nl).Append("</Profile>").Append(nl);
            return sb.ToString();
        }
    }
}
