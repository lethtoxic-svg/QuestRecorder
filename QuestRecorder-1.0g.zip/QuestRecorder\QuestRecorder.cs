// Quest Recorder - made by LethToxic.
using System;
using System.Text;
using System.Windows.Forms;
using System.Windows.Input;
using BuddyCron.Inheritables;
using BuddyCron.Profiles;
using Reborn.Utilities;

namespace QuestRecorder
{
    /// <summary>
    /// Quest Recorder: you play by hand (bot stopped) and it writes what you did, with exact names, ids and positions,
    /// as a timeline (.txt), a table (.csv) and a ready-to-load questing profile.
    /// <list type="bullet">
    /// <item>Read-only: it never moves, targets, clicks or calls game script functions.</item>
    /// <item>No OnPulse: the bot loop is not involved. A recording runs on its own background thread (Recorder) and
    /// pauses while the bot runs.</item>
    /// <item>Disabling the plugin, unloading it or closing BuddyCron stops the recording and finishes its files.</item>
    /// </list>
    /// </summary>
    public class QuestRecorderPlugin : BotPlugin
    {
        /// <summary>The patch name, SWTOR style: 1.0, 1.1, 1.1a, 1.2.1 ...</summary>
        internal const string Patch = "1.0g";

        internal static readonly Version PluginVersion = Updater.ToVersion(Patch);

        private const string HotkeyName = "Quest Recorder add marker";
        private const int StopWaitMs = 3000;

        private readonly object _formSync = new object();
        private RrForm _form;
        private bool _hotkeyRegistered;

        public override string Author
        {
            get { return "LethToxic"; }
        }

        public override string Name
        {
            get { return "Quest Recorder"; }
        }

        public override Version Version
        {
            get { return PluginVersion; }
        }

        public override string Description
        {
            get
            {
                return "Records what you do by hand (bot stopped): quests, talks, clicks, taxis, elevators, kills, markers, " +
                       "with exact names, ids and positions. Writes a timeline, a CSV and a DRAFT questing profile.";
            }
        }

        public override bool WantButton
        {
            get { return true; }
        }

        public override string ButtonText
        {
            get { return "Quest Recorder"; }
        }

        // ------------------------------------------------------------------ lifecycle

        public override void OnInitialize()
        {
            RrLog.Debug("Quest Recorder {0} loaded.", Patch);
            Updater.CheckInBackground(); // check for updates as soon as BuddyCron starts, ticked or not
        }

        public override void OnEnabled()
        {
            try
            {
                RrLog.ResetRateLimits();
                RrLog.Verbose = RrSettings.Instance.VerboseLogging;
                if (RrSettings.Instance.AutoRecord)
                {
                    // record everything you play by hand without opening the window.
                    RrLog.Info("Quest Recorder {0} enabled. Auto-record: {1}", Patch, StartRecording());
                }
                else
                {
                    RrLog.Info("Quest Recorder {0} on. Click the Quest Recorder button to start recording (with the bot stopped).", Patch);
                }
            }
            catch (Exception ex)
            {
                RrLog.Exception("Enabling Quest Recorder", ex);
            }
        }

        public override void OnDisabled()
        {
            // Called on BuddyCron's window thread: only ask the recording to stop. It finishes its files (tag check,
            // final draft) on its own thread, so the BuddyCron window never waits for it. The plugin stays loaded, and
            // Start recording refuses to start a second recorder while the old one is still finishing.
            StopEverything("the plugin was disabled", false, false, 0);
        }

        public override void OnShutdown()
        {
            StopEverything("BuddyCron is closing", true, true, StopWaitMs);
        }

        public override void Dispose()
        {
            StopEverything("the plugin was unloaded", true, true, StopWaitMs);
            base.Dispose();
        }

        /// <param name="waitMs">0 = do not wait; otherwise wait (bounded) for the recorder thread to finish.</param>
        private void StopEverything(string why, bool quick, bool closeForm, int waitMs)
        {
            try
            {
                UnregisterHotkey();
            }
            catch
            {
                // never throw from a lifecycle call
            }
            try
            {
                // On unload / shutdown wait (bounded, quick finish without the tag check) so a reload never leaves an
                // old recorder thread next to the new copy of the plugin.
                if (waitMs > 0)
                    Recorder.StopAndWait(waitMs, why, quick);
                else
                    Recorder.RequestStop(why, quick);
            }
            catch (Exception ex)
            {
                RrLog.Debug("Stopping the recorder failed: {0}", ex.Message);
            }
            if (!closeForm)
                return;
            RrForm form;
            lock (_formSync)
            {
                form = _form;
                _form = null;
            }
            if (form == null)
                return;
            try
            {
                if (form.IsDisposed)
                    return;
                if (form.InvokeRequired)
                    form.BeginInvoke(new Action(form.Close));
                else
                    form.Close();
            }
            catch
            {
                // the window is already gone
            }
        }

        // ------------------------------------------------------------------ window

        public override void OnButtonPress()
        {
            try
            {
                RrForm form;
                lock (_formSync)
                {
                    if (_form == null || _form.IsDisposed)
                        _form = new RrForm(this);
                    form = _form;
                }
                form.Show();
                form.Activate();
            }
            catch (ArgumentOutOfRangeException)
            {
                // WinForms quirk when the window was on a monitor that is gone
            }
            catch (Exception ex)
            {
                RrLog.Exception("Opening the Quest Recorder window", ex);
            }
        }

        // ------------------------------------------------------------------ recording (UI thread)

        internal string StartRecording()
        {
            string msg;
            if (!Recorder.Start(out msg))
                return msg;
            ApplyHotkey();
            bool botRunning = false;
            try
            {
                botRunning = Recorder.BotOwnsGame();
            }
            catch
            {
                botRunning = false;
            }
            return botRunning
                ? "Recording started. The bot is running: the recorder waits until you stop it."
                : "Recording started. Play by hand; click Stop recording when you are done.";
        }

        internal void StopRecording(string why)
        {
            Recorder.RequestStop(why, false);
            UnregisterHotkey();
        }

        /// <summary>The window saw the recording end (for example after an error): the hotkey goes too.</summary>
        internal void OnRecordingEnded()
        {
            UnregisterHotkey();
        }

        // ------------------------------------------------------------------ hotkey (only while recording)

        /// <summary>(Re)registers the Add marker hotkey from the settings. Call from the UI thread.</summary>
        internal void ApplyHotkey()
        {
            UnregisterHotkey();
            if (!Recorder.IsRecording)
                return;
            ApplyUndoHotkey();
            Keys combo;
            try
            {
                combo = RrSettings.Instance.MarkerHotkey;
            }
            catch
            {
                return;
            }
            if (combo == Keys.None)
                return;
            Keys key = combo & Keys.KeyCode;
            Keys mods = combo & Keys.Modifiers;
            if (key == Keys.None || mods == Keys.None)
            {
                RrLog.Warn("Marker hotkey {0} ignored: use Ctrl, Alt or Shift together with a key.", combo);
                return;
            }
            ModifierKeys modifiers = ModifierKeys.None;
            if ((mods & Keys.Control) == Keys.Control)
                modifiers |= ModifierKeys.Control;
            if ((mods & Keys.Shift) == Keys.Shift)
                modifiers |= ModifierKeys.Shift;
            if ((mods & Keys.Alt) == Keys.Alt)
                modifiers |= ModifierKeys.Alt;
            try
            {
                HotkeyManager.Register(HotkeyName, key, modifiers, hk => OnHotkey());
                _hotkeyRegistered = true;
                RrLog.Info("Press {0} to add a marker at your position (the window's note box names it).", KeyText(combo));
            }
            catch (Exception ex)
            {
                RrLog.Exception("Registering the marker hotkey", ex);
            }
        }

        private const string UndoHotkeyName = "Quest Recorder undo last action";
        private bool _undoRegistered;

        /// <summary>"Undo last action": right after a misclick, the profile forgets your last object click.</summary>
        private void ApplyUndoHotkey()
        {
            Keys combo;
            try
            {
                combo = RrSettings.Instance.UndoHotkey;
            }
            catch
            {
                return;
            }
            Keys key = combo & Keys.KeyCode;
            Keys mods = combo & Keys.Modifiers;
            if (combo == Keys.None || key == Keys.None || mods == Keys.None)
                return;
            ModifierKeys modifiers = ModifierKeys.None;
            if ((mods & Keys.Control) == Keys.Control)
                modifiers |= ModifierKeys.Control;
            if ((mods & Keys.Shift) == Keys.Shift)
                modifiers |= ModifierKeys.Shift;
            if ((mods & Keys.Alt) == Keys.Alt)
                modifiers |= ModifierKeys.Alt;
            try
            {
                HotkeyManager.Register(UndoHotkeyName, key, modifiers, hk => OnUndoHotkey());
                _undoRegistered = true;
                RrLog.Info("Press {0} right after a misclick to undo your last object click.", KeyText(combo));
            }
            catch (Exception ex)
            {
                RrLog.Exception("Registering the undo hotkey", ex);
            }
        }

        private static void OnUndoHotkey()
        {
            try
            {
                if (Recorder.AddMarker(ReplayBuilder.UndoNote, "hotkey"))
                    RrLog.Info("Undone - that last click won't be in the profile.");
            }
            catch (Exception ex)
            {
                RrLog.Debug("Undo hotkey failed: {0}", ex.Message);
            }
        }

        private void UnregisterHotkey()
        {
            if (_undoRegistered)
            {
                _undoRegistered = false;
                try
                {
                    HotkeyManager.Unregister(UndoHotkeyName);
                }
                catch (Exception ex)
                {
                    RrLog.Debug("Unregistering the undo hotkey failed: {0}", ex.Message);
                }
            }
            if (!_hotkeyRegistered)
                return;
            _hotkeyRegistered = false;
            try
            {
                HotkeyManager.Unregister(HotkeyName);
            }
            catch (Exception ex)
            {
                RrLog.Debug("Unregistering the marker hotkey failed: {0}", ex.Message);
            }
        }

        private static void OnHotkey()
        {
            try
            {
                string note = RrForm.TakeNoteForHotkey();
                if (!Recorder.AddMarker(note, "hotkey"))
                    RrLog.Info("Not recording: the marker hotkey does nothing.");
            }
            catch (Exception ex)
            {
                RrLog.Debug("Marker hotkey failed: {0}", ex.Message);
            }
        }

        private static string KeyText(Keys combo)
        {
            var sb = new StringBuilder();
            if ((combo & Keys.Control) == Keys.Control)
                sb.Append("Ctrl+");
            if ((combo & Keys.Alt) == Keys.Alt)
                sb.Append("Alt+");
            if ((combo & Keys.Shift) == Keys.Shift)
                sb.Append("Shift+");
            sb.Append((combo & Keys.KeyCode).ToString());
            return sb.ToString();
        }
    }
}
