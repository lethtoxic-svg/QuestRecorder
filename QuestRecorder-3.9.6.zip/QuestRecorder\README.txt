Quest Recorder 3.9 BETA - a BuddyCron plugin by LethToxic
===================================================

Play a quest area by hand once. Quest Recorder writes down everything you do and turns it into a
ready-to-load profile that plays it the way you did: the same objects, in the same order, at the same
spots, the same fights, the same talks and hand-ins.

It only reads the game. It never moves you, targets, clicks or uses anything.


INSTALL
-------
1. Copy this whole QuestRecorder folder into BuddyCron's Plugins folder, so you end up with
   BuddyCron\Plugins\QuestRecorder\QuestRecorder.cs (and the other files next to it).
2. Start (or restart) BuddyCron. It compiles the plugin by itself. The log should say
   "Quest Recorder 3.9.x loaded" with no "Compiler Error".
3. Tick "Quest Recorder" in the plugin list.


RECORD A RUN
------------
1. Stop the bot. Tick Quest Recorder: it starts recording by itself ("Auto-record", on by default).
2. Play the quests by hand, the way you want the bot to do them.
   - Misclicked something? Press Ctrl+Shift+Z straight away: that click is left out.
   - Want an exact walk point (a door, a phase edge, a corner)? Press Ctrl+Shift+M there.
3. Click "Stop recording" in the Quest Recorder window (or untick the plugin) when you are done.

The bot running pauses the recording (only what you do by hand is recorded; Combat Assist is fine).
Loading screens and character changes are handled.


THE PROFILE IT MAKES
--------------------
While you play, the profile is saved where your profiles live, as "<place> - Recorded <date time>.xml":
the folder set in "Profile folder", else a folder in BuddyCron whose name contains the place (for CZ-198
a folder like "CZ-198 Dailies"), else Profiles\Recorded\<place> - one folder per planet. The log says where.

How it plays:
- Every object you used is its own step, at your exact spot, in your order. Each one is tied to the quest
  count (BuddyCron's TaskValue): it is done the moment the count goes past where it was, so it never
  loops on a used object.
- Your fights stop at the kill counts you were at, at the spots the mobs died, in the order you killed
  them (adds before a boss).
- A mob that came out of an object you used (a droid from a pod) is matched to that object.
- Talks, quest items, holocom calls, pick-ups and hand-ins are where you did them.
- Get credit for your run: in the Quest Recorder window set "Your name for credits" (section 1). Every profile you
  record then says "Recorded by <your name>" under "Made by Quest Recorder - LethToxic".
- Mission items that move you (the Heroic Transport shuttle next to a heroic) are used again from the same spot,
  so the bot does not quick travel and run there.
- Elevators are taken to the floor you picked.
- It walks your footsteps between steps. Elevators and taxis are left to BuddyCron's navigator: the profile
  walks to where you came out of a lift, only while you are still on the side you rode from.
- Every step is skipped once its quest progress is there, so after a restart it carries on where it stopped.


TASK TRACKER (window) AND IN-GAME WARNINGS
-----------------------------------------
The Quest Recorder window shows a live Task tracker: every quest task / step as it ticks, with its count
and what the profile will do for it. A line with "!!" means the count went up but the recorder did not see
what you used. You also get a message on top of the game when that happens (needs BuddyCron's overlay
switched on in its settings) - redo that one while you are there.


MAKE A PROFILE FROM AN OLD RECORDING
------------------------------------
Click "Make profile from a recording" in the window and pick a recording (.csv). The plugin builds the
profile from it with its current rules - no need to play it again. The Task tracker then lists the steps.


FIX A PROFILE (no XML needed)
-----------------------------
Click "Fix a profile" in the Quest Recorder window and open the profile. You see its steps as a plain list.
- Pick a step, then Remove step / Move up / Move down.
- Or add a new step before it: stand in the game, target what you need, pick what to add and click Add step:
  click / use my target, talk to my target, fight my target's kind of mob, walk to where I am standing,
  take the elevator I am targeting (pick the floor), use a mission item here, wait some seconds, show a message.
  "For which quest step" makes it run until that quest step is done (it waits for a respawning object);
  "Just once" does it one time.
Every change is saved straight away with a backup (in a "_fixer backups" folder next to the profile).
"Undo last fix" puts the previous version back. Load the profile again in BuddyCron after fixing it.


WHAT YOU GET IN THE RECORDINGS FOLDER
-------------------------------------
"Open recordings folder" opens it. Each recording makes:
  <place>-<date>_<time>.txt        the timeline, easy to read
  <place>-<date>_<time>.csv        the same, one row per event (this is what "Make profile" reads)
The .txt has your character name in it. The profile and draft do not.


GOOD TO KNOW
------------
- The world changes every run (spawns, other players): the bot uses your objects at your spots, so if
  another player just used yours it waits for it to come back.
- Your mistakes are copied too: walk the route you want, and use Ctrl+Shift+Z after a misclick.
- Reward choices are left to BuddyCron (it picks by your gear). Dark / light: the profile follows the side
  you mostly picked.
- Run a new profile once and watch it before you share it.


UPDATES
-------
When BuddyCron starts, Quest Recorder checks LethToxic's Quest Recorder page for a newer version (it only looks).
If there is one, the window says so: click Updates, read what's new, and say Yes to install it. Your current
version is backed up to BuddyCron\PluginBackups first. Restart BuddyCron to finish. "Undo update" goes back.


IF SOMETHING IS WRONG
---------------------
- Look for lines starting with "[Quest Recorder]" in the BuddyCron log.
- "Nothing was recorded": your character was not in the world, or BuddyCron was not attached.
- A "!!" line in the Task tracker: redo that task, or add that step by hand.
- If looks at the game get slow, the recorder slows down by itself; set "Cache refresh" back to Light.
