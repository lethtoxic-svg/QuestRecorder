// Quest Recorder - made by LethToxic.
using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Threading.Tasks;

namespace QuestRecorder
{
    /// <summary>
    /// Updates (LethToxic, 2026-11-03): the plugin checks LethToxic's Quest Recorder repository for a newer version and
    /// offers an "Update now" button. Nothing is installed without the player clicking it. Updating backs up the current
    /// plugin to BuddyCron\PluginBackups (outside Plugins, so BuddyCron does not compile it twice), puts the new files in,
    /// and BuddyCron builds them on the next start. "Undo update" puts the backup back.
    /// The repository holds latest.txt (line 1: version, line 2: zip file name, then what's new) and the zip.
    /// </summary>
    internal static class Updater
    {
        /// <summary>Where updates come from (LethToxic's GitHub repository, raw files of its main branch).</summary>
        public const string Source = "https://raw.githubusercontent.com/lethtoxic-svg/QuestRecorder/main/";

        public static volatile string LatestVersion = string.Empty;
        public static volatile string LatestZip = string.Empty;
        public static volatile string WhatsNew = string.Empty;
        public static volatile string Problem = string.Empty;

        public static bool UpdateAvailable
        {
            get
            {
                Version v;
                return Version.TryParse(LatestVersion, out v) && v > QuestRecorderPlugin.PluginVersion && LatestZip.Length > 0;
            }
        }

        private static HttpClient Http()
        {
            var h = new HttpClient { Timeout = TimeSpan.FromSeconds(20) };
            h.DefaultRequestHeaders.UserAgent.ParseAdd("QuestRecorder/" + QuestRecorderPlugin.PluginVersion);
            return h;
        }

        /// <summary>Reads latest.txt in the background; never throws.</summary>
        public static void CheckInBackground()
        {
            Task.Run(async () =>
            {
                try
                {
                    using (HttpClient h = Http())
                    {
                        string text = await h.GetStringAsync(Source + "latest.txt").ConfigureAwait(false);
                        string[] lines = text.Replace("\r", string.Empty).Split('\n');
                        LatestVersion = lines.Length > 0 ? lines[0].Trim() : string.Empty;
                        LatestZip = lines.Length > 1 ? lines[1].Trim() : string.Empty;
                        WhatsNew = lines.Length > 2 ? string.Join("\r\n", lines, 2, lines.Length - 2).Trim() : string.Empty;
                        Problem = string.Empty;
                        if (UpdateAvailable)
                            RrLog.Info("Quest Recorder {0} is available (you have {1}). Open the Quest Recorder window and click Update now.", LatestVersion, QuestRecorderPlugin.PluginVersion);
                    }
                }
                catch (Exception ex)
                {
                    Problem = ex.Message;
                    RrLog.Debug("Update check failed: {0}", ex.Message);
                }
            });
        }

        private static string PluginFolder()
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Plugins", "QuestRecorder");
        }

        private static string BackupRoot()
        {
            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PluginBackups");
        }

        /// <summary>Downloads and installs the latest version. Returns a message for the player.</summary>
        public static async Task<string> InstallAsync()
        {
            if (!UpdateAvailable)
                return "No update available.";
            string zipName = LatestZip;
            if (zipName.IndexOfAny(new[] { '/', '\\', ':' }) >= 0 || !zipName.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
                return "The update file name looks wrong; not installing it.";
            string temp = Path.Combine(Path.GetTempPath(), "QuestRecorderUpdate");
            if (Directory.Exists(temp))
                Directory.Delete(temp, true);
            Directory.CreateDirectory(temp);
            string zipPath = Path.Combine(temp, "update.zip");
            using (HttpClient h = Http())
            {
                byte[] data = await h.GetByteArrayAsync(Source + Uri.EscapeDataString(zipName)).ConfigureAwait(false);
                File.WriteAllBytes(zipPath, data);
            }
            string unpacked = Path.Combine(temp, "files");
            ZipFile.ExtractToDirectory(zipPath, unpacked);
            // the zip holds a QuestRecorder folder (or the files directly)
            string src = Path.Combine(unpacked, "QuestRecorder");
            if (!Directory.Exists(src))
                src = unpacked;
            if (!File.Exists(Path.Combine(src, "QuestRecorder.cs")))
                return "The update does not look like Quest Recorder (no QuestRecorder.cs); nothing was changed.";

            string dest = PluginFolder();
            string backup = Path.Combine(BackupRoot(), "QuestRecorder " + QuestRecorderPlugin.PluginVersion + " " +
                                         DateTime.Now.ToString("yyyy-MM-dd HH-mm", CultureInfo.InvariantCulture));
            Directory.CreateDirectory(backup);
            foreach (string f in Directory.GetFiles(dest))
                File.Copy(f, Path.Combine(backup, Path.GetFileName(f)), true);
            // replace the code files (old .cs files the new version no longer has are removed, so nothing stale compiles)
            foreach (string f in Directory.GetFiles(dest, "*.cs"))
                File.Delete(f);
            foreach (string f in Directory.GetFiles(src))
                File.Copy(f, Path.Combine(dest, Path.GetFileName(f)), true);
            return "Quest Recorder " + LatestVersion + " is installed. Restart BuddyCron to finish (it builds the plugin when it starts).\r\n" +
                   "Your old version was saved in " + backup + " - \"Undo update\" puts it back.";
        }

        /// <summary>Puts the most recent backup back. Returns a message for the player.</summary>
        public static string UndoLast()
        {
            string root = BackupRoot();
            if (!Directory.Exists(root))
                return "There is no backup to go back to.";
            string newest = null;
            DateTime best = DateTime.MinValue;
            foreach (string d in Directory.GetDirectories(root, "QuestRecorder *"))
            {
                DateTime w = Directory.GetCreationTime(d);
                if (newest == null || w > best)
                {
                    newest = d;
                    best = w;
                }
            }
            if (newest == null)
                return "There is no backup to go back to.";
            string dest = PluginFolder();
            foreach (string f in Directory.GetFiles(dest, "*.cs"))
                File.Delete(f);
            foreach (string f in Directory.GetFiles(newest))
                File.Copy(f, Path.Combine(dest, Path.GetFileName(f)), true);
            Directory.Delete(newest, true);
            return "Put back " + Path.GetFileName(newest) + ". Restart BuddyCron to finish.";
        }
    }
}
