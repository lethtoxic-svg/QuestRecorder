// Quest Recorder - made by LethToxic.
using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using Reborn.Utilities.Settings;

namespace QuestRecorder
{
    /// <summary>Which tag the draft uses for "walk to this spot".</summary>
    public enum StandTag
    {
        /// <summary>Like our own profiles (walk there without stopping to fight).</summary>
        NoCombatMoveTo = 0,

        /// <summary>Like Kick's profiles.</summary>
        MoveTo = 1,
    }

    /// <summary>What the draft does with the automatic every-25-metres points.</summary>
    public enum BreadcrumbsInDraft
    {
        /// <summary>Leave them out of the draft (they stay in the .txt and .csv).</summary>
        Off = 0,

        /// <summary>Write them as commented-out stand lines you can switch on.</summary>
        AsComments = 1,

        /// <summary>Write them as real stand lines.</summary>
        AsStands = 2,
    }


    /// <summary>How much of BuddyCron's object cache the recorder refreshes before each look while the bot is stopped.</summary>
    public enum CacheRefresh
    {
        /// <summary>Only the world objects (enough for the recorder, lightest, raises no game events).</summary>
        Light = 0,

        /// <summary>Every manager, as BuddyCron documents for one-shot reads (heavier; also runs BuddyCron's game-event checks).</summary>
        Full = 1,
    }

    /// <summary>
    /// Quest Recorder settings: one file for the whole BuddyCron install, Settings\QuestRecorder\Settings.json.
    /// Every setter saves the file (JsonSettings.SetField). The recorder thread only reads these values.
    /// </summary>
    public class RrSettings : JsonSettings
    {
        private static readonly object InstanceSync = new object();
        private static RrSettings _instance;

        public static RrSettings Instance
        {
            get
            {
                RrSettings s = _instance;
                if (s != null)
                    return s;
                lock (InstanceSync)
                {
                    if (_instance == null)
                        _instance = Create();
                    return _instance;
                }
            }
        }

        private static RrSettings Create()
        {
            string dir = Path.Combine(JsonSettings.SettingsPath, "QuestRecorder");
            try
            {
                Directory.CreateDirectory(dir);
            }
            catch
            {
                // JsonSettings keeps the defaults if the file cannot be written
            }
            return new RrSettings(Path.Combine(dir, "Settings.json"));
        }

        public RrSettings(string path)
            : base(path)
        {
        }

        private static int Clamp(int v, int min, int max)
        {
            return v < min ? min : (v > max ? max : v);
        }

        // ------------------------------------------------------------------ 1. Recording

        private bool _autoRecord = true;

        [Category("1. Recording")]
        [DisplayName("Auto-record")]
        [Description("Start recording by itself as soon as the plugin is ticked (also when BuddyCron starts with it ticked). " +
                     "It records only what you play by hand: it pauses while the bot runs and waits during loading screens. " +
                     "The timeline is written as you go and the draft is refreshed every minute. Default on.")]
        [DefaultValue(true)]
        public bool AutoRecord
        {
            get { return _autoRecord; }
            set { SetField(ref _autoRecord, value, nameof(AutoRecord)); }
        }

        private string _creditName = string.Empty;

        [Category("1. Recording")]
        [DisplayName("Your name for credits")]
        [Description("Optional. Your name or nickname: every profile you record gets a line \"Recorded by <name>\" next to \"Made by Quest Recorder - LethToxic\", so you get credit when you share it. Leave empty for none.")]
        [DefaultValue("")]
        public string CreditName
        {
            get { return _creditName ?? string.Empty; }
            set { SetField(ref _creditName, (value ?? string.Empty).Trim(), nameof(CreditName)); }
        }
        private string _profileFolder = string.Empty;

        [Category("1. Recording")]
        [DisplayName("Profile folder")]
        [Description("Where the ready-to-load profile is saved as you play (\"<place> - Recorded <date>.xml\", updated every minute). " +
                     "Empty = a folder in BuddyCron whose name contains the place (e.g. \"CZ-198 Dailies\" for CZ-198), else Profiles\\Recorded\\<place> (one folder per planet).")]
        [DefaultValue("")]
        public string ProfileFolder
        {
            get { return _profileFolder; }
            set { SetField(ref _profileFolder, value ?? string.Empty, nameof(ProfileFolder)); }
        }


        private Keys _undoHotkey = Keys.Control | Keys.Shift | Keys.Z;

        [Category("2. Markers")]
        [DisplayName("Undo last action hotkey")]
        [Description("Press this in the game right after a misclick: the recorder forgets your last object click. " +
                     "Must use Ctrl, Alt or Shift plus a key. None = no hotkey. Default Ctrl+Shift+Z.")]
        [DefaultValue(Keys.Control | Keys.Shift | Keys.Z)]
        public Keys UndoHotkey
        {
            get { return _undoHotkey; }
            set { SetField(ref _undoHotkey, value, nameof(UndoHotkey)); }
        }

        private int _sampleMs;

        [Category("1. Recording")]
        [DisplayName("Look every (ms)")]
        [Description("How often the recorder looks at the game, in milliseconds. 300 to 1000. Default 400. Each look " +
                     "pauses the game for only a few milliseconds.")]
        [DefaultValue(400)]
        public int SampleMs
        {
            get { return _sampleMs; }
            set { SetField(ref _sampleMs, Clamp(value, 300, 1000), nameof(SampleMs)); }
        }

        private int _breadcrumbMeters;

        [Category("1. Recording")]
        [DisplayName("Breadcrumb every (m)")]
        [Description("Write a position point every this many metres you move. 0 = off. 5 to 200. Default 5 (the replay profile follows these footsteps).")]
        [DefaultValue(5)]
        public int BreadcrumbMeters
        {
            get { return _breadcrumbMeters; }
            set { SetField(ref _breadcrumbMeters, value <= 0 ? 0 : Clamp(value, 5, 200), nameof(BreadcrumbMeters)); }
        }

        private int _jumpMeters;

        [Category("1. Recording")]
        [DisplayName("Jump distance (m)")]
        [Description("A sudden position change at least this big counts as a jump (elevator, shuttle, quick travel, " +
                     "phase door) and is written with the position before and after. 10 to 500. Default 30.")]
        [DefaultValue(30)]
        public int JumpMeters
        {
            get { return _jumpMeters; }
            set { SetField(ref _jumpMeters, Clamp(value, 10, 500), nameof(JumpMeters)); }
        }

        private int _partnerRadius;

        [Category("1. Recording")]
        [DisplayName("Talk partner search (m)")]
        [Description("When a conversation starts and you did not click or target anyone, the nearest NPC with a quest " +
                     "marker within this many metres is taken as the person you talk to (marked as a guess). 3 to 20. Default 8.")]
        [DefaultValue(8)]
        public int PartnerRadius
        {
            get { return _partnerRadius; }
            set { SetField(ref _partnerRadius, Clamp(value, 3, 20), nameof(PartnerRadius)); }
        }

        private bool _readQuestText;

        [Category("1. Recording")]
        [DisplayName("Read objective text")]
        [Description("Look up the journal text of each quest objective (for example \"Speak with Duke Kendoh\"). " +
                     "Experimental: if the game does not give it, the recorder turns this off by itself for the session.")]
        [DefaultValue(true)]
        public bool ReadQuestText
        {
            get { return _readQuestText; }
            set { SetField(ref _readQuestText, value, nameof(ReadQuestText)); }
        }

        private CacheRefresh _refresh;

        [Category("1. Recording")]
        [DisplayName("Cache refresh")]
        [Description("Light (default) refreshes only BuddyCron's world-object list before each look. Full refreshes " +
                     "every manager. Try Full only if names or kills are missing while the bot is stopped.")]
        [DefaultValue(CacheRefresh.Light)]
        public CacheRefresh Refresh
        {
            get { return _refresh; }
            set { SetField(ref _refresh, value, nameof(Refresh)); }
        }

        // ------------------------------------------------------------------ 2. Markers

        private Keys _markerHotkey;

        [Category("2. Markers")]
        [DisplayName("Add marker hotkey")]
        [Description("Press this in the game to drop a marker at your exact position (the note box in this window is " +
                     "used as the marker's name). Must use Ctrl, Alt or Shift plus a key. Only active while recording. " +
                     "None = no hotkey. Default Ctrl+Shift+M.")]
        [DefaultValue(Keys.Control | Keys.Shift | Keys.M)]
        public Keys MarkerHotkey
        {
            get { return _markerHotkey; }
            set { SetField(ref _markerHotkey, value, nameof(MarkerHotkey)); }
        }

        // ------------------------------------------------------------------ 3. Output

        private bool _keepDraft;

        [Category("3. Output")]
        [DisplayName("Keep notes draft")]
        [Description("Also write <recording>-draft.xml next to the recording: an annotated skeleton with notes, for people who build profiles by hand. It is NOT the profile to run - the ready profile is saved in Profiles\\Recorded\\<place>. Default off.")]
        [DefaultValue(false)]
        public bool KeepDraft
        {
            get { return _keepDraft; }
            set { SetField(ref _keepDraft, value, nameof(KeepDraft)); }
        }
        private string _outputFolder = string.Empty;

        [Category("3. Output")]
        [DisplayName("Recordings folder")]
        [Description("Where recordings are written. Empty (default) = the \"Recordings\" folder next to BuddyCron's " +
                     "Logs folder.")]
        [DefaultValue("")]
        public string OutputFolder
        {
            get { return _outputFolder ?? string.Empty; }
            set { SetField(ref _outputFolder, (value ?? string.Empty).Trim(), nameof(OutputFolder)); }
        }

        private StandTag _standTag;

        [Category("3. Output")]
        [DisplayName("Stand tag in draft")]
        [Description("NoCombatMoveTo (default, like our profiles) or MoveTo (like Kick's). If BuddyCron does not know " +
                     "NoCombatMoveTo, the draft uses MoveTo by itself.")]
        [DefaultValue(StandTag.NoCombatMoveTo)]
        public StandTag DraftStandTag
        {
            get { return _standTag; }
            set { SetField(ref _standTag, value, nameof(DraftStandTag)); }
        }

        private BreadcrumbsInDraft _draftBreadcrumbs;

        [Category("3. Output")]
        [DisplayName("Breadcrumbs in draft")]
        [Description("Off, AsComments (default: commented-out stand lines, at most 8 per stretch) or AsStands.")]
        [DefaultValue(BreadcrumbsInDraft.AsComments)]
        public BreadcrumbsInDraft DraftBreadcrumbs
        {
            get { return _draftBreadcrumbs; }
            set { SetField(ref _draftBreadcrumbs, value, nameof(DraftBreadcrumbs)); }
        }

        private int _draftWaitTime;

        [Category("3. Output")]
        [DisplayName("WaitTime in draft (s)")]
        [Description("WaitTime written on TalkTo, Interact and UseObject lines, in seconds (as in our profiles). 1 to 30. Default 5.")]
        [DefaultValue(5)]
        public int DraftWaitTime
        {
            get { return _draftWaitTime; }
            set { SetField(ref _draftWaitTime, Clamp(value, 1, 30), nameof(DraftWaitTime)); }
        }

        // ------------------------------------------------------------------ 4. Log

        private bool _logEvents;

        [Category("4. Log")]
        [DisplayName("Show events in log")]
        [Description("Also write the important events (quests, talks, clicks, rides, kills, markers) to the BuddyCron log " +
                     "while recording. Breadcrumbs are never logged.")]
        [DefaultValue(true)]
        public bool LogEvents
        {
            get { return _logEvents; }
            set { SetField(ref _logEvents, value, nameof(LogEvents)); }
        }

        private bool _verbose;

        [Category("4. Log")]
        [DisplayName("Verbose logging")]
        [Description("Show Quest Recorder's diagnostic lines in the main log (for troubleshooting).")]
        [DefaultValue(false)]
        public bool VerboseLogging
        {
            get { return _verbose; }
            set { SetField(ref _verbose, value, nameof(VerboseLogging)); }
        }
    }
}
