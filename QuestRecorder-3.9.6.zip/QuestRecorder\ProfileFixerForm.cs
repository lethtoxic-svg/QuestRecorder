// Quest Recorder - made by LethToxic.
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Numerics;
using System.Windows.Forms;
using BuddyCron;
using BuddyCron.Objects;

namespace QuestRecorder
{
    /// <summary>
    /// Profile Fixer window (LethToxic, 2026-11-03): fix a profile without opening the XML. Pick a profile, pick a
    /// step, then remove it, move it, or add a step before it from what you have targeted / where you stand in the game.
    /// Every change is saved at once with a backup, and "Undo last fix" puts the previous version back.
    /// It only reads the game (your position, target, quests and mission items); it never moves or clicks anything.
    /// </summary>
    internal sealed class ProfileFixerForm : Form
    {
        private const string ActClick = "Click / use my target (an object)";
        private const string ActTalk = "Talk to my target (an NPC)";
        private const string ActFight = "Fight my target's kind of mob";
        private const string ActWalk = "Walk to where I am standing";
        private const string ActLift = "Take the elevator I am targeting";
        private const string ActItem = "Use a mission item where I am standing";
        private const string ActWait = "Wait some seconds";
        private const string ActMessage = "Show a message to the player";

        private sealed class QuestChoice
        {
            public ulong Id;
            public ulong Branch;
            public ulong Step;
            public string Name = string.Empty;

            public override string ToString()
            {
                return Id == 0 ? "Just once (not tied to a quest)" : Name + " (until this step is done: step " + Step + ")";
            }
        }

        private readonly Label _file;
        private readonly ListBox _steps;
        private readonly ComboBox _action;
        private readonly ComboBox _quest;
        private readonly ComboBox _extra;
        private readonly Label _extraLabel;
        private readonly Label _status;
        private ProfileEditor _ed;
        private List<ProfileEditor.StepView> _views = new List<ProfileEditor.StepView>();

        public ProfileFixerForm()
        {
            Text = "Quest Recorder - Profile Fixer";
            ClientSize = new Size(760, 640);
            MinimumSize = new Size(600, 480);
            StartPosition = FormStartPosition.CenterScreen;

            var top = new FlowLayoutPanel { Dock = DockStyle.Top, AutoSize = true, Padding = new Padding(4), WrapContents = true };
            top.Controls.Add(MakeButton("Open profile...", OnOpen));
            top.Controls.Add(MakeButton("Undo last fix", OnUndo));
            _file = new Label { AutoSize = true, Margin = new Padding(8, 8, 3, 3), Text = "No profile open." };
            top.Controls.Add(_file);

            _steps = new ListBox { Dock = DockStyle.Fill, IntegralHeight = false, HorizontalScrollbar = true, Font = new Font(FontFamily.GenericMonospace, 8.5f) };

            var edit = new FlowLayoutPanel { Dock = DockStyle.Bottom, AutoSize = true, Padding = new Padding(4), WrapContents = true };
            edit.Controls.Add(MakeButton("Remove step", OnRemove));
            edit.Controls.Add(MakeButton("Move up", (s, e) => OnMove(-1)));
            edit.Controls.Add(MakeButton("Move down", (s, e) => OnMove(1)));

            var add = new TableLayoutPanel { Dock = DockStyle.Bottom, AutoSize = true, ColumnCount = 3, Padding = new Padding(4) };
            add.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            add.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            add.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));

            add.Controls.Add(new Label { Text = "Add before the selected step:", AutoSize = true, Margin = new Padding(3, 7, 3, 3) }, 0, 0);
            _action = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            _action.Items.AddRange(new object[] { ActClick, ActTalk, ActFight, ActWalk, ActLift, ActItem, ActWait, ActMessage });
            _action.SelectedIndexChanged += (s, e) => OnActionChanged();
            add.Controls.Add(_action, 1, 0);
            add.Controls.Add(MakeButton("Refresh from game", (s, e) => { LoadQuests(); OnActionChanged(); }), 2, 0);

            add.Controls.Add(new Label { Text = "For which quest step:", AutoSize = true, Margin = new Padding(3, 7, 3, 3) }, 0, 1);
            _quest = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            add.Controls.Add(_quest, 1, 1);

            _extraLabel = new Label { Text = "Details:", AutoSize = true, Margin = new Padding(3, 7, 3, 3) };
            add.Controls.Add(_extraLabel, 0, 2);
            _extra = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDown };
            add.Controls.Add(_extra, 1, 2);
            add.Controls.Add(MakeButton("Add step", OnAdd), 2, 2);

            _status = new Label
            {
                Dock = DockStyle.Bottom,
                Height = 54,
                Padding = new Padding(6, 4, 6, 4),
                Text = "1. Open a profile.  2. Pick a step.  3. Remove / move it, or stand in the game, target what you need, pick what to add and click Add step.\r\n" +
                       "Every change is saved straight away and a backup is kept: \"Undo last fix\" puts the previous version back.",
            };

            Controls.Add(_steps);
            Controls.Add(edit);
            Controls.Add(add);
            Controls.Add(_status);
            Controls.Add(top);
            _steps.BringToFront();

            _action.SelectedIndex = 0;
            LoadQuests();
        }

        private static Button MakeButton(string text, EventHandler click)
        {
            var b = new Button { Text = text, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Margin = new Padding(3) };
            b.Click += click;
            return b;
        }

        private void Say(string text)
        {
            _status.Text = text;
        }

        // ------------------------------------------------------------------ profile

        private void OnOpen(object sender, EventArgs e)
        {
            try
            {
                using (var dlg = new OpenFileDialog())
                {
                    dlg.Title = "Pick the profile to fix";
                    dlg.Filter = "Profiles (*.xml)|*.xml";
                    string start = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Profiles", "Recorded");
                    if (Directory.Exists(start))
                        dlg.InitialDirectory = start;
                    if (dlg.ShowDialog(this) != DialogResult.OK)
                        return;
                    _ed = ProfileEditor.Open(dlg.FileName);
                    _file.Text = Path.GetFileName(dlg.FileName);
                    ShowSteps(0);
                    Say("Opened. Pick a step. Tip: load this profile again in BuddyCron after fixing it (BuddyCron only reads it when you load it).");
                }
            }
            catch (Exception ex)
            {
                Say("Could not open that profile: " + ex.Message);
            }
        }

        private void ShowSteps(int select)
        {
            _views = _ed != null ? _ed.Steps() : new List<ProfileEditor.StepView>();
            _steps.BeginUpdate();
            _steps.Items.Clear();
            for (int i = 0; i < _views.Count; i++)
                _steps.Items.Add((i + 1).ToString().PadLeft(3) + ". " + _views[i].Text);
            _steps.Items.Add("     (end of the profile)");
            _steps.EndUpdate();
            if (_steps.Items.Count > 0)
                _steps.SelectedIndex = Math.Max(0, Math.Min(select, _steps.Items.Count - 1));
        }

        private ProfileEditor.StepView Selected()
        {
            int i = _steps.SelectedIndex;
            return i >= 0 && i < _views.Count ? _views[i] : null;
        }

        private bool Ready()
        {
            if (_ed != null)
                return true;
            Say("Open a profile first.");
            return false;
        }

        private void OnRemove(object sender, EventArgs e)
        {
            if (!Ready())
                return;
            ProfileEditor.StepView s = Selected();
            if (s == null)
            {
                Say("Pick the step to remove.");
                return;
            }
            if (MessageBox.Show(this, "Remove this step?\r\n\r\n" + s.Text, "Profile Fixer", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;
            int at = _steps.SelectedIndex;
            _ed.Remove(s);
            SaveAndShow(at, "Step removed.");
        }

        private void OnMove(int dir)
        {
            if (!Ready())
                return;
            ProfileEditor.StepView s = Selected();
            if (s == null)
            {
                Say("Pick the step to move.");
                return;
            }
            int at = _steps.SelectedIndex;
            _ed.Move(s, dir);
            SaveAndShow(at + dir, dir < 0 ? "Step moved up." : "Step moved down.");
        }

        private void OnUndo(object sender, EventArgs e)
        {
            if (!Ready())
                return;
            try
            {
                string path = _ed.Path;
                if (ProfileEditor.UndoLast(path) == null)
                {
                    Say("Nothing to undo for this profile.");
                    return;
                }
                _ed = ProfileEditor.Open(path);
                ShowSteps(_steps.SelectedIndex);
                Say("Undone: the profile is back to how it was before the last fix.");
            }
            catch (Exception ex)
            {
                Say("Undo failed: " + ex.Message);
            }
        }

        private void SaveAndShow(int select, string what)
        {
            try
            {
                _ed.Save();
                string path = _ed.Path;
                _ed = ProfileEditor.Open(path); // re-read what was written
                ShowSteps(select);
                Say(what + " Saved (a backup was kept - \"Undo last fix\" puts it back). Load the profile again in BuddyCron to use it.");
            }
            catch (Exception ex)
            {
                Say("Saving failed: " + ex.Message);
            }
        }

        // ------------------------------------------------------------------ game reads (read only)

        private sealed class GameView
        {
            public Vector3 Me;
            public bool HasTarget;
            public string TargetName = string.Empty;
            public Vector3 TargetPos;
            public bool TargetIsObject;
            public bool TargetIsLift;
            public List<string> Floors = new List<string>();
            public List<string> Items = new List<string>();
            public List<QuestChoice> Quests = new List<QuestChoice>();
        }

        private static GameView ReadGame()
        {
            var g = new GameView();
            if (!Core.IsInitialized)
                return g;
            using (Core.Memory.AcquireFrame(true))
            {
                var me = Core.Me;
                if (me == null)
                    return g;
                g.Me = me.Location;
                // your target can be an NPC or an object: look it up by id (Core.Target only gives characters)
                HeroObject target = me.TargetId != 0 ? global::BuddyCron.Managers.HeroObjectManager.GetByNodeId(me.TargetId) : null;
                if (target != null && target.IsValid && target.Name != null)
                {
                    g.HasTarget = true;
                    g.TargetName = target.Name;
                    g.TargetPos = target.Location;
                    var plc = target as HeroPlaceable;
                    g.TargetIsObject = plc != null;
                    if (plc != null && plc.IsWonkavator)
                    {
                        g.TargetIsLift = true;
                        IReadOnlyList<string> d = plc.WonkavatorDestinations;
                        if (d != null)
                            foreach (string f in d)
                                g.Floors.Add(Fmt.OneLine(f));
                    }
                }
                try
                {
                    foreach (HeroItem item in me.QuestItems)
                    {
                        if (item == null || g.Items.Count >= 40)
                            continue;
                        string n = Fmt.OneLine(item.Name);
                        if (n.Length > 0 && !g.Items.Contains(n))
                            g.Items.Add(n);
                    }
                }
                catch
                {
                    // no mission items
                }
                foreach (QuestState st in me.Quests.ActiveQuestStates)
                {
                    if (st == null || st.QuestId == 0 || st.IsHidden)
                        continue;
                    g.Quests.Add(new QuestChoice { Id = st.QuestId, Branch = st.BranchId, Step = st.StepId, Name = Fmt.OneLine(st.DisplayName) });
                }
            }
            return g;
        }

        private void LoadQuests()
        {
            try
            {
                GameView g = ReadGame();
                object keep = _quest.SelectedItem;
                _quest.Items.Clear();
                _quest.Items.Add(new QuestChoice());
                foreach (QuestChoice q in g.Quests)
                    _quest.Items.Add(q);
                _quest.SelectedIndex = 0;
                if (keep is QuestChoice)
                {
                    for (int i = 0; i < _quest.Items.Count; i++)
                        if (((QuestChoice)_quest.Items[i]).Id == ((QuestChoice)keep).Id)
                            _quest.SelectedIndex = i;
                }
            }
            catch (Exception ex)
            {
                Say("Could not read your quests from the game: " + ex.Message);
            }
        }

        private void OnActionChanged()
        {
            string a = _action.SelectedItem as string ?? string.Empty;
            _extra.Items.Clear();
            _extra.Text = string.Empty;
            _extra.Enabled = true;
            try
            {
                if (a == ActLift)
                {
                    _extraLabel.Text = "Floor:";
                    GameView g = ReadGame();
                    foreach (string f in g.Floors)
                        _extra.Items.Add(f);
                    if (_extra.Items.Count > 0)
                        _extra.SelectedIndex = 0;
                    Say(g.TargetIsLift ? "Pick the floor to go to." : "Target the elevator in the game first, then click Refresh from game.");
                }
                else if (a == ActItem)
                {
                    _extraLabel.Text = "Mission item:";
                    GameView g = ReadGame();
                    foreach (string it in g.Items)
                        _extra.Items.Add(it);
                    if (_extra.Items.Count > 0)
                        _extra.SelectedIndex = 0;
                    Say(g.Items.Count > 0 ? "Pick the mission item. The bot will use it from where you are standing now." : "No mission items found in your quest log.");
                }
                else if (a == ActWait)
                {
                    _extraLabel.Text = "Seconds:";
                    _extra.Items.AddRange(new object[] { "3", "5", "10", "20", "30", "60" });
                    _extra.SelectedIndex = 1;
                }
                else if (a == ActMessage)
                {
                    _extraLabel.Text = "Message:";
                    _extra.Text = "Do this part by hand, then press Continue.";
                }
                else
                {
                    _extraLabel.Text = "Details:";
                    _extra.Enabled = false;
                    if (a == ActWalk)
                        Say("Stand where the bot should walk to, then click Add step.");
                    else
                        Say(a == ActClick
                            ? "Target the object in the game, then pick: a quest step = keep using it until that step is done (waits if it has to respawn); \"Just once\" = click it one time (use this for things that start a fight or open a door)."
                            : "Target it in the game, pick the quest step it is for, then click Add step.");
                }
            }
            catch (Exception ex)
            {
                Say("Could not read the game: " + ex.Message);
            }
        }

        // ------------------------------------------------------------------ add

        private void OnAdd(object sender, EventArgs e)
        {
            if (!Ready())
                return;
            string a = _action.SelectedItem as string ?? string.Empty;
            var q = _quest.SelectedItem as QuestChoice ?? new QuestChoice();
            ProfileEditor.StepView before = Selected();
            try
            {
                GameView g = ReadGame();
                string xml;
                string what;
                if (a == ActClick || a == ActTalk || a == ActFight || a == ActLift)
                {
                    if (!g.HasTarget)
                    {
                        Say("Nothing is targeted in the game. Target it first, then click Add step.");
                        return;
                    }
                }
                if (a == ActClick)
                {
                    if (!g.TargetIsObject)
                    {
                        Say("Your target is not an object. For an NPC use \"" + ActTalk + "\".");
                        return;
                    }
                    xml = ProfileEditor.ClickObject(g.TargetName, g.TargetPos.X, g.TargetPos.Y, g.TargetPos.Z, q.Id, q.Branch, q.Step);
                    what = "use " + g.TargetName;
                }
                else if (a == ActTalk)
                {
                    xml = ProfileEditor.TalkTo(g.TargetName, g.TargetPos.X, g.TargetPos.Y, g.TargetPos.Z, q.Id, q.Branch, q.Step);
                    what = "talk to " + g.TargetName;
                }
                else if (a == ActFight)
                {
                    if (q.Id == 0)
                    {
                        Say("Pick the quest step this fight is for, so the bot knows when to stop.");
                        return;
                    }
                    xml = ProfileEditor.Fight(g.TargetName, g.TargetPos.X, g.TargetPos.Y, g.TargetPos.Z, q.Id, q.Branch, q.Step);
                    what = "fight " + g.TargetName;
                }
                else if (a == ActWalk)
                {
                    xml = ProfileEditor.WalkHere(g.Me.X, g.Me.Y, g.Me.Z, q.Id, q.Branch, q.Step);
                    what = "walk here";
                }
                else if (a == ActLift)
                {
                    if (!g.TargetIsLift)
                    {
                        Say("Your target is not an elevator.");
                        return;
                    }
                    string floor = _extra.Text.Trim();
                    if (floor.Length == 0)
                    {
                        Say("Pick the floor.");
                        return;
                    }
                    xml = ProfileEditor.Elevator(g.TargetName, floor, g.TargetPos.X, g.TargetPos.Y, g.TargetPos.Z, q.Id, q.Branch, q.Step);
                    what = "take " + g.TargetName + " to " + floor;
                }
                else if (a == ActItem)
                {
                    string item = _extra.Text.Trim();
                    if (item.Length == 0)
                    {
                        Say("Pick the mission item.");
                        return;
                    }
                    xml = ProfileEditor.UseMissionItem(item, g.Me.X, g.Me.Y, g.Me.Z, q.Id, q.Branch, q.Step);
                    what = "use " + item;
                }
                else if (a == ActWait)
                {
                    int sec;
                    if (!int.TryParse(_extra.Text.Trim(), out sec) || sec <= 0)
                    {
                        Say("Type how many seconds to wait.");
                        return;
                    }
                    xml = ProfileEditor.Wait(sec);
                    what = "wait " + sec + " s";
                }
                else if (a == ActMessage)
                {
                    string msg = _extra.Text.Trim();
                    if (msg.Length == 0)
                    {
                        Say("Type the message.");
                        return;
                    }
                    xml = ProfileEditor.Message(msg);
                    what = "message";
                }
                else
                {
                    Say("Pick what to add.");
                    return;
                }
                int at = _steps.SelectedIndex;
                _ed.Add(xml, "Added with Profile Fixer: " + what + (q.Id != 0 ? " (" + q.Name + ")" : string.Empty), before);
                SaveAndShow(at, "Added: " + what + ".");
            }
            catch (Exception ex)
            {
                Say("Could not add it: " + ex.Message);
            }
        }
    }
}
