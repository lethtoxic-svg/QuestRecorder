// Quest Recorder - made by LethToxic.
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace QuestRecorder
{
    /// <summary>
    /// The Quest Recorder window: status, Start / Stop / Add marker / Open folder, the marker note box and the
    /// settings (PropertyGrid). Closing the window does not stop a recording.
    /// </summary>
    internal sealed class RrForm : Form
    {
        // The hotkey callback may come on any thread: it reads the note from here, and the window clears the box.
        private static volatile string _noteForHotkey = string.Empty;
        private static int _noteTaken;

        private readonly QuestRecorderPlugin _plugin;
        private readonly PropertyGrid _grid;
        private readonly Label _status;
        private readonly TextBox _note;
        private readonly Button _start;
        private readonly Button _stop;
        private readonly Button _marker;
        private readonly System.Windows.Forms.Timer _timer;
        private readonly TextBox _tracker;
        private string[] _shownTrace;
        private bool _wasRunning;

        public RrForm(QuestRecorderPlugin plugin)
        {
            _plugin = plugin;
            Text = "Quest Recorder " + QuestRecorderPlugin.PluginVersion;
            ClientSize = new Size(640, 760);
            MinimumSize = new Size(400, 460);
            StartPosition = FormStartPosition.CenterScreen;

            _grid = new PropertyGrid
            {
                Dock = DockStyle.Fill,
                ToolbarVisible = false,
                PropertySort = PropertySort.Categorized,
                HelpVisible = true,
            };
            _grid.PropertyValueChanged += OnPropertyValueChanged;

            _status = new Label
            {
                Dock = DockStyle.Top,
                AutoSize = false,
                Height = 96,
                Padding = new Padding(6, 6, 6, 2),
                Text = "Not recording.",
            };

            var buttons = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                Padding = new Padding(4),
            };
            _start = MakeButton("Start recording", OnStartClick);
            _stop = MakeButton("Stop recording", OnStopClick);
            _marker = MakeButton("Add marker", OnMarkerClick);
            buttons.Controls.Add(_start);
            buttons.Controls.Add(_stop);
            buttons.Controls.Add(_marker);
            buttons.Controls.Add(MakeButton("Open recordings folder", OnFolderClick));
            buttons.Controls.Add(MakeButton("Make profile from a recording", OnMakeProfileClick));
            buttons.Controls.Add(MakeButton("Fix a profile", OnFixProfileClick));
            buttons.Controls.Add(MakeButton("Updates", OnUpdatesClick));
            buttons.Controls.Add(MakeButton("Undo update", OnUndoUpdateClick));

            var noteRow = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                ColumnCount = 2,
                RowCount = 1,
                Padding = new Padding(4, 0, 4, 4),
            };
            noteRow.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            noteRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
            var noteLabel = new Label { Text = "Marker note:", AutoSize = true, Anchor = AnchorStyles.Left, Margin = new Padding(3, 6, 3, 3) };
            _note = new TextBox { Dock = DockStyle.Fill, Margin = new Padding(3) };
            _note.TextChanged += OnNoteChanged;
            _note.KeyDown += OnNoteKeyDown;
            noteRow.Controls.Add(noteLabel, 0, 0);
            noteRow.Controls.Add(_note, 1, 0);

            // Docking lays out from the last added control: add the Fill control first, then the rows from the bottom
            // up (note row, buttons, status), and keep the grid in front.
            // Task tracker (2026-10-31): every quest task caught so far and what the profile will do for it
            _tracker = new TextBox
            {
                Dock = DockStyle.Bottom,
                Height = 240,
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Both,
                WordWrap = false,
                Font = new Font(FontFamily.GenericMonospace, 8.5f),
                Text = "Task tracker: each quest task you complete shows here with what the profile will do for it.\r\n" +
                       "A line with !! means no action was caught for that task - redo it or press Add marker there.",
            };
            var trackerLabel = new Label { Dock = DockStyle.Bottom, Height = 18, Padding = new Padding(6, 2, 6, 0), Text = "Task tracker (live)" };

            Controls.Add(_grid);
            Controls.Add(trackerLabel);
            Controls.Add(_tracker);
            Controls.Add(noteRow);
            Controls.Add(buttons);
            Controls.Add(_status);
            _grid.BringToFront();

            try
            {
                _grid.SelectedObject = RrSettings.Instance;
            }
            catch (Exception ex)
            {
                RrLog.Exception("Loading the Quest Recorder settings", ex);
            }

            _timer = new System.Windows.Forms.Timer { Interval = 500 };
            _timer.Tick += OnTick;
            _timer.Start();
            FormClosed += OnFormClosed;
            RefreshStatus();
        }

        private static Button MakeButton(string text, EventHandler click)
        {
            var b = new Button { Text = text, AutoSize = true, AutoSizeMode = AutoSizeMode.GrowAndShrink, Margin = new Padding(3) };
            b.Click += click;
            return b;
        }

        /// <summary>Called by the marker hotkey (any thread): the note typed in the window, which is then cleared.</summary>
        internal static string TakeNoteForHotkey()
        {
            string n = _noteForHotkey ?? string.Empty;
            if (n.Length > 0)
            {
                _noteForHotkey = string.Empty;
                Interlocked.Exchange(ref _noteTaken, 1);
            }
            return n;
        }

        private void OnNoteChanged(object sender, EventArgs e)
        {
            _noteForHotkey = _note.Text ?? string.Empty;
        }

        private void OnNoteKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && Recorder.IsRecording)
            {
                e.SuppressKeyPress = true;
                OnMarkerClick(sender, EventArgs.Empty);
            }
        }

        private void OnFormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                _timer.Stop();
                _timer.Dispose();
            }
            catch
            {
                // ignore
            }
        }

        private void OnTick(object sender, EventArgs e)
        {
            try
            {
                if (Interlocked.Exchange(ref _noteTaken, 0) == 1)
                    _note.Clear();
                RefreshStatus();
            }
            catch (Exception ex)
            {
                if (RrLog.Every("form-tick", TimeSpan.FromMinutes(5)))
                    RrLog.Debug("Window refresh failed: {0}", ex.Message);
            }
        }

        private void RefreshStatus()
        {
            RecorderStatus st = Recorder.Status;
            bool running = Recorder.IsRecording;
            if (_wasRunning && !running)
                _plugin.OnRecordingEnded(); // the recording ended by itself or from elsewhere: drop the hotkey
            _wasRunning = running;

            _start.Enabled = !running;
            _stop.Enabled = running && !st.Stopping;
            _marker.Enabled = running && !st.Stopping;

            var sb = new StringBuilder();
            if (running)
            {
                sb.Append(st.Stopping ? "Stopping, writing the files..." : "Recording " + Fmt.Duration(st.Seconds));
                if (st.Place.Length > 0)
                    sb.Append(" on ").Append(st.Place);
                sb.Append(" - ").Append(st.StateText).Append("\r\n");
                sb.Append(Fmt.Format("{0} events: {1} quest updates, {2} kills, {3} markers{4}\r\n", st.Events, st.QuestEvents, st.Kills,
                    st.Markers, st.Warnings > 0 ? ", " + st.Warnings.ToString() + " warnings" : string.Empty));
                if (st.LastEvent.Length > 0)
                    sb.Append("Last: ").Append(st.LastEvent).Append("\r\n");
                if (st.BaseName.Length > 0)
                    sb.Append("Files: ").Append(Path.Combine(st.Folder, st.BaseName)).Append(" (.txt, .csv)");
            }
            else
            {
                sb.Append("Not recording. Stop the bot, click Start recording, then play by hand.\r\n");
                if (st.Result.Length > 0)
                    sb.Append("Last recording: ").Append(st.Result);
            }
            if (Updater.UpdateAvailable)
                sb.Append("\r\nUpdate available: Quest Recorder ").Append(Updater.LatestVersion).Append(" - click Updates.");
            string text = sb.ToString();
            if (_status.Text != text)
                _status.Text = text;

            string[] trace = RecordingSession.LiveTrace;
            if (trace != null && trace.Length > 0 && !ReferenceEquals(trace, _shownTrace))
            {
                _shownTrace = trace;
                _tracker.Text = string.Join("\r\n", trace);
                _tracker.SelectionStart = _tracker.TextLength;
                _tracker.ScrollToCaret();
            }
        }

        private void OnStartClick(object sender, EventArgs e)
        {
            try
            {
                string msg = _plugin.StartRecording();
                if (!string.IsNullOrEmpty(msg))
                    RrLog.Info("{0}", msg);
                RefreshStatus();
            }
            catch (Exception ex)
            {
                RrLog.Exception("Starting the recording", ex);
            }
        }

        private void OnStopClick(object sender, EventArgs e)
        {
            try
            {
                _plugin.StopRecording("you clicked Stop");
                RefreshStatus();
            }
            catch (Exception ex)
            {
                RrLog.Exception("Stopping the recording", ex);
            }
        }

        private void OnMarkerClick(object sender, EventArgs e)
        {
            try
            {
                string note = _note.Text ?? string.Empty;
                if (Recorder.AddMarker(note, "button"))
                {
                    _note.Clear();
                }
                else
                {
                    RrLog.Info("Not recording: click Start recording first.");
                }
            }
            catch (Exception ex)
            {
                RrLog.Exception("Adding the marker", ex);
            }
        }

        private void OnFolderClick(object sender, EventArgs e)
        {
            string dir = null;
            try
            {
                dir = RecordingSession.ResolveFolder();
                Directory.CreateDirectory(dir);
                Process.Start(new ProcessStartInfo { FileName = dir, UseShellExecute = true });
            }
            catch (Exception ex)
            {
                RrLog.Warn("Could not open {0}: {1}", dir ?? "the recordings folder", ex.Message);
            }
        }

        /// <summary>Updates: check, show what's new, install only when the player says yes (LethToxic, 2026-11-03).</summary>
        private async void OnUpdatesClick(object sender, EventArgs e)
        {
            try
            {
                if (!Updater.UpdateAvailable)
                {
                    Updater.CheckInBackground();
                    await System.Threading.Tasks.Task.Delay(3000);
                }
                if (!Updater.UpdateAvailable)
                {
                    string why = Updater.Problem.Length > 0 ? "\r\n\r\n(Could not reach the update page: " + Updater.Problem + ")" : string.Empty;
                    MessageBox.Show(this, "You have the latest Quest Recorder (" + QuestRecorderPlugin.PluginVersion + ")." + why, "Quest Recorder", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                string news = Updater.WhatsNew.Length > 0 ? "\r\n\r\nWhat's new:\r\n" + Updater.WhatsNew : string.Empty;
                if (MessageBox.Show(this, "Quest Recorder " + Updater.LatestVersion + " is available (you have " + QuestRecorderPlugin.PluginVersion + ")." + news +
                                          "\r\n\r\nInstall it now? Your current version is backed up first.", "Quest Recorder update", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    return;
                string msg = await Updater.InstallAsync();
                RrLog.Info(msg.Replace("\r\n", " "));
                MessageBox.Show(this, msg, "Quest Recorder update", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                RrLog.Exception("Updating Quest Recorder", ex);
                MessageBox.Show(this, "The update did not work: " + ex.Message + "\r\nNothing was lost; your current version is still there.", "Quest Recorder update", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void OnUndoUpdateClick(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show(this, "Go back to the Quest Recorder version you had before the last update?", "Quest Recorder", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                    return;
                string msg = Updater.UndoLast();
                RrLog.Info(msg);
                MessageBox.Show(this, msg, "Quest Recorder", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                RrLog.Exception("Undoing the update", ex);
            }
        }

        private ProfileFixerForm _fixer;

        /// <summary>Profile Fixer: fix a profile without opening the XML (LethToxic, 2026-11-03).</summary>
        private void OnFixProfileClick(object sender, EventArgs e)
        {
            try
            {
                if (_fixer == null || _fixer.IsDisposed)
                    _fixer = new ProfileFixerForm();
                _fixer.Show();
                _fixer.Activate();
            }
            catch (Exception ex)
            {
                RrLog.Exception("Opening the Profile Fixer", ex);
            }
        }

        /// <summary>Pick a recording (.csv): the plugin builds the ready profile from it, no need to play it again (2026-10-30).</summary>
        private void OnMakeProfileClick(object sender, EventArgs e)
        {
            try
            {
                string dir = RecordingSession.ResolveFolder();
                using (var dlg = new OpenFileDialog())
                {
                    dlg.Title = "Pick a recording (.csv) to make a profile from";
                    dlg.Filter = "Quest Recorder recordings (*.csv)|*.csv";
                    if (Directory.Exists(dir))
                        dlg.InitialDirectory = dir;
                    if (dlg.ShowDialog(this) != DialogResult.OK)
                        return;
                    ReplayBuilder.CreditName = RrSettings.Instance.CreditName;
                    string path = RecordingLoader.MakeProfile(dlg.FileName, AppDomain.CurrentDomain.BaseDirectory, RrSettings.Instance.ProfileFolder);
                    RrLog.Info("Made a profile from {0}: {1}", Path.GetFileName(dlg.FileName), path);
                    MessageBox.Show(this, "Profile made from your recording:\r\n\r\n" + path + "\r\n\r\nLoad it in BuddyCron to run it.", "Quest Recorder",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                RrLog.Exception("Making a profile from a recording", ex);
                MessageBox.Show(this, "Could not make the profile: " + ex.Message, "Quest Recorder", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void OnPropertyValueChanged(object s, PropertyValueChangedEventArgs e)
        {
            try
            {
                if (e.ChangedItem == null || e.ChangedItem.PropertyDescriptor == null)
                    return;
                string name = e.ChangedItem.PropertyDescriptor.Name;
                if (name == nameof(RrSettings.MarkerHotkey))
                {
                    if (Recorder.IsRecording)
                        _plugin.ApplyHotkey();
                }
                else if (name == nameof(RrSettings.VerboseLogging))
                {
                    RrLog.Verbose = RrSettings.Instance.VerboseLogging;
                }
            }
            catch (Exception ex)
            {
                RrLog.Exception("Applying the setting", ex);
            }
        }
    }
}
