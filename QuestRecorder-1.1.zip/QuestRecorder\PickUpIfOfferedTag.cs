// Quest Recorder - made by LethToxic.
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;
using BuddyCron;
using BuddyCron.Behaviors;
using BuddyCron.Managers;
using BuddyCron.Navigation;
using BuddyCron.Objects;
using BuddyCron.Objects.Oracle;
using BuddyCron.Objects.Static;
using BuddyCron.Profiles;
using BuddyCron.ServiceClient;
using Reborn.Behaviors.Coroutines;
using Reborn.Behaviors.Treesharp;
using Reborn.Utilities.Math;
using Reborn.Utilities.XmlEngine;

namespace QuestBehaviors
{
    /// <summary>
    /// &lt;PickUpIfOffered QuestId="..." GiverName="..." XYZ="..." /&gt; works like PickUpQuest, but if the giver doesn't
    /// offer the quest (a daily or heroic you already did today) it gives up after a few tries instead of clicking forever.
    /// </summary>
    [XmlElement("PickUpIfOffered")]
    public class PickUpIfOfferedTag : ProfileBehavior
    {
        private bool _gaveUp;
        private int _tries;
        private int _talkWaits;
        private Stopwatch _clock;

        [XmlAttribute("GiverName")]
        [XmlAttribute("Name")]
        public string ObjectName { get; set; } = string.Empty;

        [XmlAttribute("XYZ")]
        public Vector3 Position { get; set; }

        [XmlAttribute("UseRange")]
        [DefaultValue(20f)]
        public float ProfileUseRange { get; set; } = 20f;

        [XmlAttribute("SearchRadius")]
        [DefaultValue(20f)]
        public float ProfileSearchRadius { get; set; } = 20f;

        /// <summary>How many clicks on the giver before giving up.</summary>
        [XmlAttribute("Tries")]
        public int Tries { get; set; } = 3;

        private float UseRange => ProfileUseRange / 10f;

        private float SearchRadius => ProfileSearchRadius / 10f;

        public override bool IsDone => _gaveUp || IsQuestComplete || HasQuest;

        public override string StatusText => "Picking up " + QuestName + " from " + ObjectName + " (if it's offered)";

        protected override void OnResetCachedDone()
        {
            _gaveUp = false;
            _tries = 0;
            _talkWaits = 0;
            _clock = null;
        }

        private HeroObject Giver()
        {
            HeroObject npc = (from c in HeroObjectManager.GetObjects<HeroCharacter>() orderby c.DistanceSqr select c).FirstOrDefault(c => c.Name == ObjectName);
            if (npc != null)
                return npc;
            return HeroObjectManager.GetObjects<HeroPlaceable>().FirstOrDefault(c => Position.DistanceSqr(c.Location) <= SearchRadius && c.Name == ObjectName);
        }

        protected override Composite CreateBehavior()
        {
            return new PrioritySelector(ctx => Giver(),
                new Decorator(ret => ret == null && Core.Me!.Location.DistanceSqr(Position) <= UseRange * UseRange, new ActionRunCoroutine(NoGiver)),
                CommonBehaviors.MoveToInteract(ret => ret as HeroObject, ret => Position, ret => UseRange, true, ret => "PickUpIfOffered: " + ObjectName + " for " + QuestName),
                new ActionRunCoroutine(Take));
        }

        private async Task<bool> NoGiver(object arg)
        {
            if (_clock == null)
                _clock = Stopwatch.StartNew();
            if (_clock.ElapsedMilliseconds > 30000)
            {
                Log(ObjectName + " isn't here - skipping " + QuestName + ".");
                _gaveUp = true;
                return true;
            }
            await Coroutine.Sleep(500);
            return true;
        }

        private async Task<bool> Take(object arg)
        {
            var giver = arg as HeroObject;
            if (giver == null || !giver.IsValid)
                return true;
            if (InConversation())
            {
                // a conversation (General Konya): BuddyCron's own dialog handling talks it through - don't click again
                await Coroutine.Sleep(500);
                if (++_talkWaits > 180)
                {
                    Log("The conversation with " + ObjectName + " didn't end in 90 s - skipping " + QuestName + ".");
                    _gaveUp = true;
                }
                return true;
            }
            _tries++;
            // Exactly what BuddyCron's own PickUpQuest does (Quest Behaviors\PickupQuestTag.cs): interact, wait for
            // the mission board / quest window, then accept the mission by its quest id.
            giver.Interact();
            if (await Coroutine.Wait(300, () => Core.Player!.MissionBoardOpen))
                HeroGuiApiGfx.Instance!.AcceptMission(QuestId);
            if (await Coroutine.Wait(3000, () => HasQuest || InConversation()))
                return true;
            if (_tries >= Tries)
            {
                Log(ObjectName + " isn't offering " + QuestName + " right now (done already today?) - skipping it.");
                _gaveUp = true;
            }
            return true;
        }

        private static bool InConversation()
        {
            HeroCnvOracle cnv = ExtraNodeManager.ConvoOracle;
            return cnv != null && cnv.IsInConversation;
        }
    }
}
