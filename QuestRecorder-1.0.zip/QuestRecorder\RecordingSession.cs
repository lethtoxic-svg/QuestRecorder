// Quest Recorder - made by LethToxic.
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Reborn.Utilities;
using Reborn.Utilities.Settings;

namespace QuestRecorder
{
    /// <summary>
    /// One recording: the .txt timeline and the .csv are written as events arrive (flushed after every look, so a
    /// crash keeps them); the draft profile is rebuilt about once a minute and at the end. Recorder thread only,
    /// never inside the frame lock.
    /// </summary>
    internal sealed class RecordingSession
    {
        public const int MaxEventsInMemory = 200000;
        private const long DraftEveryMs = 60000;

        public readonly string Folder;
        public readonly string BaseName;
        public readonly string TxtPath;
        public readonly string CsvPath;
        public readonly string DraftPath;
        public readonly string Place;
        public readonly DateTime Started;

        private readonly List<RecEvent> _events = new List<RecEvent>();
        private StreamWriter _txt;
        private StreamWriter _csv;
        private int _seq;
        private bool _draftDirty;
        private long _lastDraftTick;
        private bool _truncated;
        private bool _writeBroken;
        private bool _draftBroken;
        private DateTime _lastTime;

        public int QuestEvents;
        public int Kills;
        public int Markers;
        public int Warnings;
        public string LastHeadline = string.Empty;

        private RecordingSession(string folder, string baseName, string place, DateTime started)
        {
            Folder = folder;
            BaseName = baseName;
            Place = place;
            LiveTrace = new string[0];
            Started = started;
            _lastTime = started;
            TxtPath = Path.Combine(folder, baseName + ".txt");
            CsvPath = Path.Combine(folder, baseName + ".csv");
            DraftPath = Path.Combine(folder, baseName + "-draft.xml");
            _lastDraftTick = Environment.TickCount64;
        }

        public int Count
        {
            get { return _seq; }
        }

        // ------------------------------------------------------------------ folder and files

        /// <summary>The Recordings folder: the setting, else next to BuddyCron's Logs folder, else next to BuddyCron.</summary>
        public static string ResolveFolder()
        {
            string custom = string.Empty;
            try
            {
                custom = RrSettings.Instance.OutputFolder;
            }
            catch
            {
                custom = string.Empty;
            }
            string root = BuddyCronFolder();
            if (custom.Length > 0)
            {
                try
                {
                    return Path.IsPathRooted(custom) ? Path.GetFullPath(custom) : Path.GetFullPath(Path.Combine(root, custom));
                }
                catch (Exception ex)
                {
                    RrLog.Warn("The recordings folder \"{0}\" is not usable ({1}); using the default one.", custom, ex.Message);
                }
            }
            return Path.Combine(root, "Recordings");
        }

        /// <summary>The folder that holds BuddyCron's Logs folder (walks up from the current log file).</summary>
        private static string BuddyCronFolder()
        {
            try
            {
                string log = Logging.LogFilePath;
                if (!string.IsNullOrEmpty(log))
                {
                    DirectoryInfo d = new FileInfo(log).Directory;
                    while (d != null)
                    {
                        if (string.Equals(d.Name, "Logs", StringComparison.OrdinalIgnoreCase) && d.Parent != null)
                            return d.Parent.FullName;
                        d = d.Parent;
                    }
                }
            }
            catch
            {
                // fall through
            }
            try
            {
                string dir = Reborn.Utilities.Utilities.AssemblyDirectory;
                if (!string.IsNullOrEmpty(dir))
                    return dir;
            }
            catch
            {
                // fall through
            }
            try
            {
                string dir = JsonSettings.AssemblyPath;
                if (!string.IsNullOrEmpty(dir))
                    return File.Exists(dir) ? Path.GetDirectoryName(dir) : dir;
            }
            catch
            {
                // fall through
            }
            return AppContext.BaseDirectory;
        }

        /// <summary>Creates the folder and the .txt / .csv files. Throws when they cannot be created.</summary>
        public static RecordingSession Create(Snap first, AreaInfo area, RrSettings cfg)
        {
            string folder = ResolveFolder();
            Directory.CreateDirectory(folder);
            string place = area.Planet.Length > 0 ? area.Planet : area.Label;
            string stem = Fmt.FileName(place, "Recording") + "-" + first.Time.ToString("yyyy-MM-dd_HH-mm", System.Globalization.CultureInfo.InvariantCulture);
            string baseName = stem;
            for (int n = 2; n < 1000; n++)
            {
                if (!File.Exists(Path.Combine(folder, baseName + ".txt")) && !File.Exists(Path.Combine(folder, baseName + ".csv")) &&
                    !File.Exists(Path.Combine(folder, baseName + "-draft.xml")))
                    break;
                baseName = stem + "-" + n.ToString();
            }

            var s = new RecordingSession(folder, baseName, place, first.Time);
            try
            {
                s._txt = OpenWriter(s.TxtPath, new UTF8Encoding(false));
                s._csv = OpenWriter(s.CsvPath, new UTF8Encoding(true)); // BOM so Excel reads the names right
                s.WriteHeader(first, area, cfg);
                s._csv.WriteLine(EventText.CsvHeader);
                s.Flush();
            }
            catch
            {
                s.CloseWriters();
                throw;
            }
            return s;
        }

        private static StreamWriter OpenWriter(string path, Encoding enc)
        {
            var fs = new FileStream(path, FileMode.CreateNew, FileAccess.Write, FileShare.ReadWrite | FileShare.Delete);
            var w = new StreamWriter(fs, enc);
            w.NewLine = "\r\n";
            return w;
        }

        private void WriteHeader(Snap first, AreaInfo area, RrSettings cfg)
        {
            _txt.WriteLine("Quest Recorder " + QuestRecorderPlugin.Patch + " - timeline");
            _txt.WriteLine("Started     " + Fmt.Stamp(first.Time));
            _txt.WriteLine("Character   " + (first.PlayerName.Length > 0 ? first.PlayerName : "(unknown)") + ", level " + Fmt.UInt(first.Level));
            _txt.WriteLine("Area        \"" + area.Label + "\" " + Fmt.Hex(area.Id) +
                           (area.Internal.Length > 0 ? " (" + area.Internal + ")" : string.Empty) +
                           (area.Planet.Length > 0 ? ", planet " + area.Planet : string.Empty));
            _txt.WriteLine(Fmt.Format("Settings    look every {0} ms, breadcrumb every {1} m, jump at {2} m, talk partner search {3} m",
                cfg.SampleMs, cfg.BreadcrumbMeters, cfg.JumpMeters, cfg.PartnerRadius));
            _txt.WriteLine("Files       " + BaseName + ".txt (this file), " + BaseName + ".csv (one row per event)");
            _txt.WriteLine("Positions   x,y,z with 3 decimals (the way profiles write XYZ). Ids in hex as profiles write them.");
            _txt.WriteLine("Quest steps branch/step are QuestState.BranchId/StepId; \"task\" is the 0-based task index.");
            _txt.WriteLine(new string('-', 100));
        }

        // ------------------------------------------------------------------ events

        public void Add(RecEvent e)
        {
            _seq++;
            e.Seq = _seq;
            e.Elapsed = Math.Max(0.0, (e.Time - Started).TotalSeconds);
            if (e.Time > _lastTime)
                _lastTime = e.Time;
            if (string.IsNullOrEmpty(e.Summary))
                e.Summary = EventText.Headline(e);

            Tally(e);
            if (e.Kind != EvKind.Breadcrumb)
                LastHeadline = Fmt.Clock(e.Time) + "  " + e.Summary;

            if (_events.Count < MaxEventsInMemory)
            {
                _events.Add(e);
                _draftDirty = true;
            }
            else if (!_truncated)
            {
                _truncated = true;
                RrLog.Warn("This recording has more than {0} events. The .txt and .csv go on; the draft covers the first {0}.", MaxEventsInMemory);
            }

            WriteEvent(e);
            LogEvent(e);
            if (e.Kind == EvKind.QuestTask || e.Kind == EvKind.QuestStep || e.Kind == EvKind.QuestAdded || e.Kind == EvKind.QuestCompleted)
                UpdateTracker();
        }

        /// <summary>Task tracker shown in the Quest Recorder window: what the profile will do for each task so far.</summary>
        public static volatile string[] LiveTrace = new string[0];
        private int _traceWarned;

        private void UpdateTracker()
        {
            try
            {
                List<string> t = ReplayBuilder.Trace(_events);
                LiveTrace = t.ToArray();
                // say it straight away when a task was ticked but no action was caught (so you can redo it while you are there)
                for (int i = _traceWarned; i < t.Count; i++)
                {
                    if (t[i].IndexOf("!!", StringComparison.Ordinal) < 0)
                        continue;
                    RrLog.Warn("Task tracker: {0}", t[i]);
                    // on screen too, over the game (BuddyCron's overlay toast)
                    string task = t[i];
                    int arrow = task.IndexOf("  ->", StringComparison.Ordinal);
                    if (arrow > 0)
                        task = task.Substring(0, arrow);
                    int dot = task.IndexOf(". ", StringComparison.Ordinal);
                    if (dot > 0 && dot < 5)
                        task = task.Substring(dot + 2);
                    if (!GameToast.Show("Quest Recorder: nothing caught for \"" + task + "\" - it did not see what you used. Redo that one if you can.", 12000) &&
                        RrLog.Every("overlay-off", TimeSpan.FromMinutes(30)))
                        RrLog.Info("(Turn on BuddyCron's overlay in its settings to see these warnings in the game.)");
                }
                _traceWarned = t.Count;
            }
            catch (Exception ex)
            {
                if (RrLog.Every("tracker", TimeSpan.FromMinutes(10)))
                    RrLog.Debug("Task tracker failed: {0}", ex.Message);
            }
        }

        private void Tally(RecEvent e)
        {
            switch (e.Kind)
            {
                case EvKind.QuestAdded:
                case EvKind.QuestStep:
                case EvKind.QuestTask:
                case EvKind.QuestCompleted:
                case EvKind.QuestAbandoned:
                case EvKind.QuestRemoved:
                    if (!e.QuestHidden)
                        QuestEvents++;
                    break;
                case EvKind.Kill:
                    Kills++;
                    break;
                case EvKind.Marker:
                    Markers++;
                    break;
                case EvKind.Warning:
                    Warnings++;
                    break;
            }
        }

        private void WriteEvent(RecEvent e)
        {
            if (_writeBroken)
                return;
            try
            {
                foreach (string line in EventText.TxtLines(e))
                    _txt.WriteLine(line);
                _csv.WriteLine(EventText.CsvRow(e));
            }
            catch (Exception ex)
            {
                _writeBroken = true;
                RrLog.Error("Writing the recording failed ({0}). The rest of this recording is kept in memory for the draft only.", ex.Message);
            }
        }

        private static void LogEvent(RecEvent e)
        {
            if (e.QuestHidden)
                return;
            bool log;
            switch (e.Kind)
            {
                case EvKind.Breadcrumb:
                case EvKind.ConvoEnd:
                case EvKind.CombatStart:
                case EvKind.CombatEnd:
                case EvKind.Mounted:
                case EvKind.Dismounted:
                case EvKind.Cast:
                case EvKind.TaxiOpen:
                case EvKind.TaxiStart:
                case EvKind.ElevatorOpen:
                case EvKind.InteractionOpen:
                case EvKind.BoardClose:
                case EvKind.Loading:
                case EvKind.Revived:
                case EvKind.NpcClick:
                case EvKind.QuestLog:
                    log = false;
                    break;
                default:
                    log = true;
                    break;
            }
            if (!log)
                return;
            bool enabled;
            try
            {
                enabled = RrSettings.Instance.LogEvents;
            }
            catch
            {
                enabled = true;
            }
            if (enabled || e.Kind == EvKind.Warning)
                RrLog.Event("{0}", e.Summary);
        }

        public void Flush()
        {
            if (_writeBroken)
                return;
            try
            {
                if (_txt != null)
                    _txt.Flush();
                if (_csv != null)
                    _csv.Flush();
            }
            catch (Exception ex)
            {
                _writeBroken = true;
                RrLog.Error("Writing the recording failed ({0}). The rest of this recording is kept in memory for the draft only.", ex.Message);
            }
        }

        // ------------------------------------------------------------------ draft

        /// <summary>Rewrites the draft about once a minute while new events arrive (cheap: pure C#, no game access).</summary>
        public void MaybeWriteDraft(long now)
        {
            if (!_draftDirty || now - _lastDraftTick < DraftEveryMs)
                return;
            _lastDraftTick = now;
            WriteDraft(false, TagCheck.Cached);
        }

        private void WriteDraft(bool final, TagCheckResult tags)
        {
            _draftDirty = false;
            string text;
            try
            {
                var info = new DraftInfo();
                info.Place = Place;
                info.Started = Started;
                info.Ended = _lastTime;
                info.BaseName = BaseName;
                info.Final = final;
                info.Truncated = _truncated;
                text = DraftBuilder.Build(_events, info, RrSettings.Instance, tags);
            }
            catch (Exception ex)
            {
                if (!_draftBroken || final)
                    RrLog.Exception("Building the draft profile", ex);
                _draftBroken = true;
                return;
            }
            // The annotated draft was mistaken for the profile (a tester ran Dromund Kaas-...-draft.xml, which has none of
            // the shuttle / terminal handling): only written when "Keep notes draft" is on.
            if (!RrSettings.Instance.KeepDraft)
            {
                WriteProfileCopy(text);
                return;
            }
            string tmp = DraftPath + ".tmp";
            try
            {
                File.WriteAllText(tmp, text, new UTF8Encoding(false));
                try
                {
                    File.Move(tmp, DraftPath, true);
                }
                catch (IOException)
                {
                    // the target is open somewhere: copy over it instead
                    File.Copy(tmp, DraftPath, true);
                    File.Delete(tmp);
                }
                catch (UnauthorizedAccessException)
                {
                    File.Copy(tmp, DraftPath, true);
                    File.Delete(tmp);
                }
            }
            catch (Exception ex)
            {
                if (final || RrLog.Every("draft-write", TimeSpan.FromMinutes(10)))
                    RrLog.Warn("Writing the draft {0} failed: {1}", DraftPath, ex.Message);
                try
                {
                    if (File.Exists(tmp))
                        File.Delete(tmp);
                }
                catch
                {
                    // ignore
                }
            }
            WriteProfileCopy(text);
        }

        // ------------------------------------------------------------------ ready-to-load profile copy

        private string _profilePath;
        private bool _profileAnnounced;

        /// <summary>
        /// The same draft, saved where players keep their profiles so it can be loaded straight away: the folder named in
        /// the settings, else a folder in the BuddyCron install whose name contains the place (e.g. "CZ-198 Dailies" for
        /// CZ-198), else Profiles\Recorded. File: "&lt;place&gt; - Recorded &lt;date time&gt;.xml", rewritten with every draft.
        /// </summary>
        private void WriteProfileCopy(string text)
        {
            try
            {
                if (_profilePath == null)
                    _profilePath = ProfileCopyPath();
                if (_profilePath.Length == 0)
                    return;
                // The ready-to-load profile is a REPLAY of the recording (every action in order, at its spot, on its
                // object); the -draft.xml next to the timeline keeps the annotated draft.
                string replay;
                try
                {
                    string place = Place.Length > 0 ? Place : "Recording";
                    string name = place + " - Recorded " + Started.ToString("yyyy-MM-dd HH:mm", System.Globalization.CultureInfo.InvariantCulture);
                    ReplayBuilder.CreditName = RrSettings.Instance.CreditName;
                    replay = ReplayBuilder.Build(_events, name, Path.GetFileName(_profilePath), BaseName);
                }
                catch (Exception ex)
                {
                    if (RrLog.Every("replay-build", TimeSpan.FromMinutes(10)))
                        RrLog.Warn("Building the replay profile failed ({0}); saving the draft instead.", ex.Message);
                    replay = text;
                }
                File.WriteAllText(_profilePath, replay, new UTF8Encoding(false));
                if (!_profileAnnounced)
                {
                    _profileAnnounced = true;
                    RrLog.Info("The profile is being written as you play: {0}", _profilePath);
                }
            }
            catch (Exception ex)
            {
                if (RrLog.Every("profile-copy", TimeSpan.FromMinutes(10)))
                    RrLog.Warn("Saving the profile copy failed: {0}", ex.Message);
            }
        }

        private string ProfileCopyPath()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string place = Place.Length > 0 ? Place : "Recording";
            var safe = new StringBuilder();
            foreach (char ch in place)
                safe.Append(Array.IndexOf(Path.GetInvalidFileNameChars(), ch) >= 0 ? '-' : ch);
            string folder = null;
            string chosen = RrSettings.Instance.ProfileFolder ?? string.Empty;
            if (chosen.Trim().Length > 0)
                folder = Path.IsPathRooted(chosen) ? chosen : Path.Combine(baseDir, chosen);
            if (folder == null && Place.Length > 0)
                folder = FindPlaceFolder(baseDir, Place);
            if (folder == null)
                folder = Path.Combine(baseDir, "Profiles", "Recorded", safe.ToString()); // one folder per planet / area
            Directory.CreateDirectory(folder);
            // two recordings started in the same minute (CZ-198-...-15-48 and -15-48-2): keep the "-2" so neither overwrites the other
            string stem = Fmt.FileName(place, "Recording") + "-" + Started.ToString("yyyy-MM-dd_HH-mm", System.Globalization.CultureInfo.InvariantCulture);
            string extra = BaseName.Length > stem.Length && BaseName.StartsWith(stem, StringComparison.Ordinal) ? " " + BaseName.Substring(stem.Length).Trim('-', ' ') : string.Empty;
            return Path.Combine(folder, safe + " - Recorded " + Started.ToString("yyyy-MM-dd HH-mm", System.Globalization.CultureInfo.InvariantCulture) + extra + ".xml");
        }

        private static readonly string[] SkipFolders = { "Recordings", "Logs", "Plugins", "Settings", "Reports", "Routines", "BotBases", "Quest Behaviors", "CompiledAssemblies", "bin", "obj", "_backup" };

        /// <summary>A folder (two levels deep at most) whose name contains the place name, e.g. LethToxic\CZ-198 Dailies.</summary>
        internal static string FindPlaceFolder(string baseDir, string place)
        {
            try
            {
                foreach (string top in Directory.GetDirectories(baseDir))
                {
                    string topName = Path.GetFileName(top);
                    if (Array.IndexOf(SkipFolders, topName) >= 0)
                        continue;
                    if (topName.IndexOf(place, StringComparison.OrdinalIgnoreCase) >= 0)
                        return top;
                    foreach (string sub in Directory.GetDirectories(top))
                    {
                        string subName = Path.GetFileName(sub);
                        if (Array.IndexOf(SkipFolders, subName) < 0 && subName.IndexOf(place, StringComparison.OrdinalIgnoreCase) >= 0)
                            return sub;
                    }
                }
            }
            catch
            {
                // unreadable folder: fall back to Profiles\Recorded
            }
            return null;
        }

        // ------------------------------------------------------------------ end

        /// <summary>Footer, close the files, final draft. Never throws.</summary>
        public void Finish(string why, IList<string> stats, bool checkTags)
        {
            try
            {
                if (!_writeBroken && _txt != null)
                {
                    _txt.WriteLine(new string('-', 100));
                    _txt.WriteLine("Stopped     " + Fmt.Stamp(DateTime.Now) + (string.IsNullOrEmpty(why) ? string.Empty : " (" + why + ")") +
                                   ", recorded " + Fmt.Duration((_lastTime - Started).TotalSeconds));
                    _txt.WriteLine(Fmt.Format("Events      {0} (quest updates {1}, kills {2}, markers {3}, warnings {4})", _seq,
                        QuestEvents, Kills, Markers, Warnings));
                    if (stats != null)
                    {
                        foreach (string line in stats)
                            _txt.WriteLine(line);
                    }
                    if (RrSettings.Instance.KeepDraft)
                        _txt.WriteLine("Draft       " + DraftPath);
                }
            }
            catch (Exception ex)
            {
                RrLog.Debug("Writing the footer failed: {0}", ex.Message);
            }
            Flush();
            CloseWriters();

            TagCheckResult tags = TagCheck.Cached;
            if (checkTags && tags == null)
            {
                try
                {
                    tags = TagCheck.Run();
                }
                catch (Exception ex)
                {
                    RrLog.Debug("Tag check failed: {0}", ex.Message);
                }
            }
            WriteDraft(true, tags);
        }

        private void CloseWriters()
        {
            try
            {
                if (_txt != null)
                    _txt.Dispose();
            }
            catch
            {
                // ignore
            }
            try
            {
                if (_csv != null)
                    _csv.Dispose();
            }
            catch
            {
                // ignore
            }
            _txt = null;
            _csv = null;
        }
    }
}
